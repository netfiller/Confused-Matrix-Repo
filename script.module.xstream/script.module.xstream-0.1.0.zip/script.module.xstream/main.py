# -*- coding: utf-8 -*-
import sys

def main():
	
	from six.moves.urllib.parse import parse_qsl
	params = dict(parse_qsl(sys.argv[2][1:]))
	tmdb_id = params.get("id")
	season = int(params.get("season", 0))
	episode = int(params.get("episode", 0))
	type = "tv" if season !=0 and episode !=0 else "movie"
	if tmdb_id:
		from resources.lib import scraper
		scraper.play(type, tmdb_id, season, episode)
	else: return

if __name__ == '__main__':
    sys.exit(main())
	
	