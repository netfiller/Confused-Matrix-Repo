# -*- coding: UTF-8 -*-
# movieking
# 2022-11-09
# edit 2023-02-23

import resolveurl as resolver
from resources.lib import workers
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting
from scrapers.modules import cleantitle, dom_parser, source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['movieking.cc']
        self.domains = [getSetting('provider.movieking.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        self.search_link = self.base_link + '/search?q=%s'
        self.get_link = 'movie/load-stream/%s/%s?server=2'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        self.hostDict = hostDict
        if season > 0: return self.sources
        aResult = []
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            self.t = [cleantitle.get(i) for i in set(titles) if i]

            for title in titles:
                query = self.search_link % title
                oRequest = cRequestHandler(query)
                sHtmlContent = oRequest.request()
                pattern = 'primary">(.*?)</span>.*?href="([^"]+)">([^<]+)'
                isMatch, aResult = cParser().parse(sHtmlContent, pattern)
                if not isMatch: continue
                elif isMatch: break

            if aResult == []: return self.sources
            threads = []
            for i in aResult:
                if cleantitle.get(i[2]) in t:
                    #print(i[2])
                    self.chk_year(i, year)
            #         threads.append(workers.Thread(self.chk_year, i, year))
            # [i.start() for i in threads]
            # [i.join() for i in threads]
            return self.sources

        except:
            return self.sources

    def resolve(self, url):
        return url

    def chk_year(self, i, year):
        try:
            quality, link, title = i
            years = ('%s' % str(year), '%s' % str(int(year) + 1), '%s' % str(int(year) - 1), '0')
            oRequest = cRequestHandler(link)
            sHtmlContent = oRequest.request()
            pattern = 'entlicht:.*?(\d{4})'
            isMatch, found_year = cParser.parseSingleResult(sHtmlContent, pattern)
            if not isMatch: return
            if found_year in years: # and any(cleantitle.get(title) in i for i in self.t):
                quality = quality.strip() if quality.strip() != '' else '720p'
                self.getHosters(sHtmlContent, quality)
        except:
            return 

    def getHosters(self, sHtmlContent, quality):
        links = dom_parser.parse_dom(sHtmlContent, 'div', attrs={'class': 'season'})
        links = dom_parser.parse_dom(links, 'a')
        links = [(i.content, i.attrs['href']) for i in links if 'movie-player-button' in i.attrs['class']]
        for hoster, link in links:
            #print(hoster+': '+ link)
            try:
                oRequest = cRequestHandler(link)
                sHtmlContent = oRequest.request()
                pattern = 'embed-item".*?src="(http[^"]+)'
                isMatch, url = cParser.parseSingleResult(sHtmlContent, pattern)
                valid, hoster = source_utils.is_host_valid(hoster, self.hostDict)
                if not valid: continue
                hmf = resolver.HostedMediaFile(url, include_disabled=True, include_universal=False)
                if hmf.valid_url():
                    url = hmf.resolve()
                    if url: self.sources.append({'source': hoster, 'quality': quality, 'language': 'de', 'url': url, 'direct': True})
            except:
                continue
