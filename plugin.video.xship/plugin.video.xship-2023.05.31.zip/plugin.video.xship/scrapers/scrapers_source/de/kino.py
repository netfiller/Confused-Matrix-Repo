# -*- coding: UTF-8 -*-
# kino
#2023-02-01
# edit 2023-02-23

#import resolveurl as resolver
from scrapers.modules.tools import cParser  # re - alternative
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, source_utils
from resources.lib.control import getSetting, urljoin

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['www.kino.ws']
        self.domains = [getSetting('provider.kino.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        self.search_link = self.base_link + '/recherche?_token=kZDYEMkRbBXOKMQbZZOnGOaR9JMeGAjXpzKtj0s3&q=%s'
        self.checkHoster = True
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        t = [cleantitle.get(i) for i in set(titles) if i]
        #years = (year, year + 1, year - 1, 0)
        links = []
        try:
            for sSearchText in titles:
                oRequest = cRequestHandler(self.search_link % sSearchText)
                sHtmlContent = oRequest.request()
                pattern = 'short.*?mask.*?href="([^"]+).*?title">([^<]+)'
                isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                for sUrl, sName in aResult:
                    if season == 0:
                        if not cleantitle.get(sName.split('-')[0].strip()) in t: continue
                        links.append(sUrl)
                    else:
                        if not 'Staffel %s' % str(season) in sName: continue
                        if not cleantitle.get(sName.split('-')[0].strip()) in t: continue
                        links.append(sUrl)

                if len(links) > 0: break

            if len(links) == 0: return self.sources
            for link in links:
                try:
                    sHtmlContent = cRequestHandler(link).request()
                    if season == 0:
                        pattern = 'radius.*?>(.*?)<.*?Jahre.*?(\d+)'
                        isMatch, aQY = cParser.parse(sHtmlContent, pattern)
                        sQuality, sYear = aQY[0]
                        if not int(sYear) == year: continue
                        pattern = '<li><a.*?"([^"]+)'
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if not isMatch: continue
                    else:
                        pattern = '<div class="tabs-sel">.*?</div>'
                        isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                        if not isMatch: continue
                        pattern = 'href="([a-z0-9/:][^"]+)'
                        isMatch, aResult = cParser.parse(aResult[episode-1], pattern)
                        if not isMatch: continue
                        sQuality = '720p'
                except:
                    continue

                for sUrl in aResult:
                    if not sUrl.startswith('http'): sUrl = urljoin('https:', sUrl)
                    valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
                    if not valid or 'youtube' in hoster: continue
                    self.sources.append({'source': hoster, 'quality': sQuality.lower(), 'language': 'de', 'url': sUrl, 'direct': False})

            return self.sources
        except:
            return self.sources

    def resolve(self, url):
        try:
            return url
        except:
            return
