# -*- coding: UTF-8 -*-
# streamen
# 2022-12-22
# edit 2023-02-06

from resources.lib.requestHandler import cRequestHandler
from scrapers.modules.tools import cParser
from resources.lib.control import urljoin, getSetting, urlparse
from scrapers.modules import cleantitle, source_utils, dom_parser

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['www.streamen.cx']
        self.domains = [getSetting('provider.streamen.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        self.search_link = self.base_link + '/recherche?q=%s'
        self.sources = []


    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            links = []
            for sSearchText in set(titles):
                URL_SEARCH = self.search_link % sSearchText
                oRequest = cRequestHandler(URL_SEARCH, caching=True)
                sHtmlContent = oRequest.request()
                pattern = 'shortstory-in.*?href="([^"]+).*?title="([^"]+)'
                isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                if not isMatch: continue
                for sUrl, sName in aResult:
                    if season == 0:
                        if cleantitle.get(sName) in set(t) and sUrl not in links:
                            links.append(sUrl)
                            break
                    else:
                        if cleantitle.get(sName) in t and sUrl not in links:
                            print(sUrl)
                            sHtmlContent = cRequestHandler(sUrl).request()
                            seasonlinks = dom_parser.parse_dom(sHtmlContent, "h4", attrs={"class": "short-link"})
                            seasonlinks = dom_parser.parse_dom(seasonlinks, "a")

                            slink = [i[0]['href'] for i in seasonlinks if 'staffel-%s' % str(season) in  i[0]['href']]
                            if slink:
                                sHtmlContent = cRequestHandler(slink[0]).request()
                                episodelinks = dom_parser.parse_dom(sHtmlContent, "div", attrs={"class": "episode-list"})
                                episodelinks = dom_parser.parse_dom(episodelinks, "a")
                                elink = [i[0]['href'] for i in episodelinks if 'folge-%s' % str(episode) in i[0]['href']]
                                if slink:
                                    links.append(elink[0])
                                    break

                if len(links) > 0: break

            if len(links) == 0: return self.sources
            for link in set(links):
                sHtmlContent = cRequestHandler(link).request()
                pattern = 'class="streamer".*?url="([^"]+).*?_5">([^\s|<]+)'
                isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                for hUrl, sHoster in aResult:
                    if sHoster == 'Player': continue
                    sUrl = urljoin(self.base_link, hUrl)
                    # oRequest = cRequestHandler(url, caching=False)
                    # oRequest.request()
                    # status = oRequest.getStatus()
                    # if status == '200': sUrl = hUrl
                    # elif 300 <= int(status) < 400:
                    #     sUrl = oRequest.getRealUrl()
                    # else: continue
                    # if 'voe' in sHoster.lower():
                    #     p = urlparse(sUrl)
                    #     sUrl = p._replace(netloc=p.netloc.replace(p.hostname, 'voe.sx')).geturl()
                    valid, hoster = source_utils.is_host_valid(sHoster, hostDict)
                    if not valid: continue
                    self.sources.append({'source': hoster, 'quality': 'HD', 'language': 'de', 'url': [sUrl, sHoster], 'direct': False})
            return self.sources
        except:
            return self.sources

    def resolve(self, url):
        try:
            sUrl = ''
            hUrl = urljoin(self.base_link, url[0])
            oRequest = cRequestHandler(hUrl, caching=False)
            oRequest.request()
            status = oRequest.getStatus()
            if 300 <= int(status) < 400:
                sUrl = oRequest.getRealUrl()
            elif status == '200':  sUrl = url
            else: return
            if 'voe' in url[1].lower():
                p = urlparse(sUrl)
                sUrl = p._replace(netloc=p.netloc.replace(p.hostname, 'voe.sx')).geturl()
            return sUrl
        except:
            return
