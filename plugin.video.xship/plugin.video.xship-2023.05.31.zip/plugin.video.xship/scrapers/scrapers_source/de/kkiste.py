# -*- coding: UTF-8 -*-
# kkiste
# 2023-01-28
# edit 2023-05-11

import re
import resolveurl as resolver
from scrapers.modules.tools import cParser  # re - alternative
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser, source_utils
from resources.lib.control import getSetting, setSetting, urljoin

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['kkiste.direct'] # direct kkiste.rocks
        self.domains = [getSetting('provider.kkiste.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        # self.search_link = urljoin(self.base_link, '/index.php?do=search')# /index.php?do=search&subaction=search&story=
        self.search_link = urljoin(self.base_link, '/index.php?do=search&subaction=search&titleonly=3&story=%s')
        self.checkHoster = False if getSetting('provider.kkiste.checkHoster') == 'false' else True
        #self.checkHoster = False # test only
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        sources = []
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            years = (year, year+1, year-1, 0)
            links = []
            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.search_link % sSearchText)
                    sHtmlContent = oRequest.request()
                    pattern = 'class="short">.*?href="([^"]+)">([^<]+).*?Jahr:.*?([\d]+)<'
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    if not isMatch:
                        continue

                    for sUrl, sName, sYear in aResult:
                        if season == 0:
                            if cleantitle.get(sName) in t and int(sYear) in years:
                                  if sUrl not in links: links.append(sUrl)
                        else:
                            if cleantitle.get(sName.split('-')[0].strip()) in t and str(season) in sName.split('-')[1]:
                                if sUrl not in links: links.append(sUrl)

                    if len(links) > 0: break
                except:
                    continue

            if len(links) == 0: return sources
            for link in set(links):
                sHtmlContent = cRequestHandler(link).request()
                if season > 0:
                    pattern = '\s%s<.*?</ul>' % episode
                    isMatch, sHtmlContent = cParser.parseSingleResult(sHtmlContent, pattern)
                    if not isMatch: return sources
                isMatch, aResult = cParser().parse(sHtmlContent, 'link="([^"]+)">')
                if not isMatch: return sources

                if self.checkHoster:
                    from resources.lib import workers
                    threads = []
                    for sUrl in aResult:
                        #print(sUrl)
                        threads.append(workers.Thread(self.chk_link, sUrl, hostDict, season, episode))
                    [i.start() for i in threads]
                    [i.join() for i in threads]
                else:
                    for sUrl in aResult:
                        if 'youtube'in sUrl or 'vod'in sUrl: continue
                        if sUrl.startswith('/'): sUrl = re.sub('//', 'https://', sUrl)
                        if sUrl.startswith('/'): sUrl = 'https:/' + sUrl
                        valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
                        if not valid: continue
                        self.sources.append({'source': hoster, 'quality': 'HD', 'language': 'de', 'url': sUrl, 'direct': False})

            return self.sources
        except:
            return self.sources

    def chk_link(self, sUrl, hostDict, season, episode):
        try:
            #if 'mixdrop' in sUrl:
            #    print(sUrl)
            if 'youtube' in sUrl or 'vod' in sUrl: return
            if sUrl.startswith('/'): sUrl = re.sub('//', 'https://', sUrl)
            if sUrl.startswith('/'): sUrl = 'https:/' + sUrl
            valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
            if not valid: return
            hmf = resolver.HostedMediaFile(url=sUrl, include_disabled=True, include_universal=False)
            if hmf.valid_url():
                url = hmf.resolve()
                if url: self.sources.append({'source': hoster, 'quality': 'HD', 'language': 'de', 'url': url, 'direct': True})
        except:
            return

    def resolve(self, url):
        try:
            return url
        except:
            return
