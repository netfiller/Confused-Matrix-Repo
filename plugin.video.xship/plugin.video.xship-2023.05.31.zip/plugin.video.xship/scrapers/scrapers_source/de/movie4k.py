# -*- coding: UTF-8 -*-
# movie4k
# 2022-11-11
# edit 2023-05-11

import re
import resolveurl as resolver
from scrapers.modules.tools import cParser  # re - alternative
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser, source_utils
from resources.lib.control import getSetting, setSetting


class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['movie4k.pics']  # alt: movie4k.wiki
        self.domains = [getSetting('provider.movie4k.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        #self.search_link = 'https://movie4k.pics/index.php?do=search&subaction=search&search_start=0&full_search=1&result_from=1&titleonly=3&story=%s'
        self.search_link = self.base_link + '/index.php?story=%s&do=search&subaction=search&titleonly=3'
        self.checkHoster = False if getSetting('provider.movie4k.checkHoster') == 'false' else True
        #self.checkHoster = False # test only
        self.sources = []


    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        sources = []
        url = ''
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            years = (year, year+1, year-1, 0)
            links = []
            for sSearchText in titles:
                try:
                    oRequest = cRequestHandler(self.search_link % sSearchText, caching=True)
                    sHtmlContent = oRequest.request()
                    pattern = 'article class.*?href="([^"]+).*?<h3>([^<]+).*?white">([^<]+)'
                    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                    if not isMatch:
                        continue

                    for sUrl, sName, sYear in aResult:
                        if season == 0:
                            if cleantitle.get(sName) in t and int(sYear) in years:
                                # url = sUrl
                                # break
                                links.append(sUrl)

                        else:
                            if cleantitle.get(sName.split('-')[0].strip()) in t and str(season) in sName.split('-')[1]:
                                links.append(sUrl)
                                #break
                    if len(links) > 0: break
                except:
                    continue

            if len(links) == 0: return sources

            for url in links:
                sHtmlContent = cRequestHandler(url).request()
                #isMatch, quality = cParser().parseSingleResult(sHtmlContent, 'Qualität:.*?span>([^<]+)')
                quality = 'HD'
                if season > 0:
                    pattern = '\s%s<.*?</ul>' % episode
                    isMatch, sHtmlContent = cParser.parseSingleResult(sHtmlContent, pattern)
                    if not isMatch: return sources

                isMatch, aResult = cParser().parse(sHtmlContent, 'link="([^"]+)">([^<]+)')

                if isMatch:
                    if self.checkHoster:
                        from resources.lib import workers
                        threads = []
                        for i in aResult:
                            if 'railer' in i[1] or 'youtube' in i[0] or 'vod' in i[0]: continue
                            # print(sUrl)
                            threads.append(workers.Thread(self.chk_link, i[0], i[1], quality, hostDict))
                        [i.start() for i in threads]
                        [i.join() for i in threads]
                        #return self.sources

                    else:
                        for sUrl, sName in aResult:
                            if 'railer' in sName or 'youtube'in sUrl or 'vod'in sUrl: continue
                            if sUrl.startswith('/'): sUrl = re.sub('//', 'https://', sUrl)
                            if sUrl.startswith('/'): sUrl = 'https:/' + sUrl
                            valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
                            if not valid: continue
                            self.sources.append({'source': hoster, 'quality': quality, 'language': 'de', 'url': sUrl, 'direct': False})

            return self.sources
        except:
            return self.sources

    def chk_link(self, sUrl, sName, quality, hostDict):
        try:
            if 'railer' in sName or 'youtube' in sUrl or 'vod' in sUrl: return
            if sUrl.startswith('/'): sUrl = re.sub('//', 'https://', sUrl)
            if sUrl.startswith('/'): sUrl = 'https:/' + sUrl
            valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
            if not valid: return
            hmf = resolver.HostedMediaFile(url=sUrl, include_disabled=True, include_universal=False)
            if hmf.valid_url():
                url = hmf.resolve()
                if url: self.sources.append({'source': hoster, 'quality': quality, 'language': 'de', 'url': url, 'direct': True})
        except:
            return

    def resolve(self, url):
        try:
            return url
        except:
            return
