# -*- coding: UTF-8 -*-
# moviedream
# 2022-12-21
# edit 2023-01-31

from resources.lib.requestHandler import cRequestHandler
from scrapers.modules.tools import cParser
from Cryptodome.Cipher import AES
from Cryptodome.Util.Padding import unpad
from Cryptodome.Hash import MD5
import base64
from scrapers.modules import source_utils
from resources.lib.control import getSetting

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['moviedream.co']
        self.domains = [getSetting('provider.moviedream.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        #self.search_link = '/search/title/%s'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        imdb = cParser.parse(imdb, '\d+')[1][0]
        if season == 0:
            URL_SEARCH = self.base_link + '/film/%s/deutsch' % imdb
            #REFERER = self.base_link + '/suchergebnisse.php?sprache=Deutsch&imdbid=%s' % imdb
        else:
            URL_SEARCH = self.base_link + '/serie/%s/deutsch/staffel-%s/episode-%s' % (imdb, str(season), str(episode))
        REFERER = self.base_link + '/suchergebnisse.php?sprache=Deutsch&imdbid=%s' % imdb
        oRequest = cRequestHandler(URL_SEARCH, caching=True)
        oRequest.addHeaderEntry('Referer', REFERER)
        sHtmlContent = oRequest.request()
        pattern = 'decrypt(\([^\)]+\))'
        isMatch, aResult = cParser.parse(sHtmlContent, pattern)

        for Result in aResult:
            password = eval(Result)[1].encode()
            decryptdict = eval(eval(Result)[0])
            ciphertext = base64.b64decode(decryptdict['ct'])
            salt = bytes.fromhex(decryptdict['s'])
            keyIv = self.bytesToKey(salt, password)
            key = keyIv[:32]
            iv = keyIv[32:]  # from key derivation
            cipher = AES.new(key, AES.MODE_CBC, iv)
            decryptedstring = unpad(cipher.decrypt(ciphertext), 16)
            url = eval(decryptedstring.decode())
            sUrl = url.replace('\\', '')
            valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
            quality = 'HD'
            if '1080' in sUrl: quality = '1080p'
            if valid:
                #print(sUrl)
                self.sources.append({'source': hoster, 'quality': quality, 'language': 'de', 'url': sUrl, 'direct': False})
        return self.sources

    def resolve(self, url):
        return url


    def bytesToKey(self, salt, password):
        data = b''
        tmp = b''
        while len(data) < 48:
            md5 = MD5.new()
            md5.update(tmp + password + salt)
            tmp = md5.digest()
            data += tmp
        return data