# -*- coding: utf-8 -*-

#edit 2023-05-26

import sys, re, requests, time, os, xbmcplugin, xbmcgui, xbmc, json, random
from resources.lib import vavooutils as utils

groupfile = os.path.join(utils.addonprofile,"groups")
favoritenfile = os.path.join(utils.addonprofile,"tvfavoriten")
url="https://www2.vavoo.to/live2/index"
home = xbmcgui.Window(10000)

def resolve_link(link):
	_data='{"token":"26fY7-FIvyz_UA5t9T_ndXB02KgaCT-jDx0uA9CE7iRAO_V2lCSGkAzzTXOpjHZHBvOoKcuq1OVCnbYX035d8698U0OYDaLo-7p8BJJIJNj7d1z-7byaQDuDFdEHPbnZAKAxG_fskVIrE0XkBV7_HbBnlIBDQ_EgxA","reason":"app-focus","locale":"de","theme":"light","metadata":{"device":{"type":"Handset","brand":"Xiaomi","model":"21081111RG","name":"21081111RG","uniqueId":"33267ca74bec24c7"},"os":{"name":"android","version":"7.1.2","abis":["arm64-v8a","armeabi-v7a","armeabi"],"host":"non-pangu-pod-sbcp6"},"app":{"platform":"android","version":"1.1.2","buildId":"97245000","engine":"jsc","signatures":["7c8c6b5030a8fa447078231e0f2c0d9ee4f24bb91f1bf9599790a1fafbeef7e0"],"installer":"com.android.secex"},"version":{"package":"net.dezor.browser","binary":"1.1.2","js":"1.2.9"}},"appFocusTime":1589,"playerActive":false,"playDuration":0,"devMode":false,"hasMhub":false,"castConnected":false,"package":"net.dezor.browser","version":"1.2.9","process":"app","firstAppStart":1681125328576,"lastAppStart":1681125328576,"ipLocation":null,"adblockEnabled":true,"proxy":{"supported":true,"enabled":true}}'
	signed = requests.post("https://www.dezor.net/api/app/ping", data=_data).json()["mhub"]
	_headers={"user-agent": "MediaHubMX/2", "accept": "application/json", "content-type": "application/json; charset=utf-8", "content-length": "158", "accept-encoding": "gzip", "Host": "www.kool.to", "mediahubmx-signature":signed}
	_data={"language":"de","region":"AT","url":link.replace("oha.to/oha-tv", "kool.to/kool-tv").replace("huhu.to/huhu-tv", "kool.to/kool-tv"),"clientVersion":"1.1.3"}
	url = "https://www.kool.to/kool-cluster/mediahubmx-resolve.json"
	return requests.post(url, data=json.dumps(_data), headers=_headers).json()[0]["url"]

def filterout(name):
	name = re.sub('( (SD|HD|FHD|UHD|H265))?( \\(BACKUP\\))? \\(\\d+\\)$', '', name)
	name = re.sub("(\(.*\)|DE : | \|C| \|E| FHD| HD| 1080| AUSTRIA| GERMANY| DEUTSCHLAND| \|D|HEVC|RAW| SD| YOU)", "", name).strip('.')
	name = name.replace('EINS', '1').replace('ZWEI', '2').replace('DREI', '3').replace('SIEBEN', '7').replace('  ', ' ').replace("TNT", "WARNER").replace('III', '3').replace('II', '2').strip()

	if "1-2-3" in name: name = "1-2-3 TV"
	elif "DAS ERSTE" in name: name = "ARD - DAS ERSTE"
	elif "EURONEWS" in name: name = "EURONEWS"
	elif "NICKEL" in name: name = "NICKELODEON"
	elif "ORF" in name:
		if "SPORT" in name: name = "ORF SPORT"
		elif "3" in name: name = "ORF 3"
		elif "2" in name: name = "ORF 2"
		elif "1" in name: name = "ORF 1"
		elif "I" in name: name = "ORF 1"
	#elif "AXN" in name: name = "AXN"
	elif "SONY" in name: 	# muss vor ANIXE stehen!
		if "AXN" in name: name = "SONY AXN"
		else: name = "SONY CHANNEL"	#TODO
	elif "ANIXE" in name:
		if "+" in name: name = name
		else: name = "ANIXE SERIE"
	elif "HEIMA" in name: name = "HEIMATKANAL"
	elif "SIXX" in name: name = "SIXX"
	elif "REPLAY" in name or "FOX" in name: name = "SKY REPLAY"
	elif "SWR" in name: name = "SWR"
	elif "CENTRAL" in name or "VIVA" in name: name = "VIVA"
	elif "BR" in name and "FERNSEHEN" in name: name = "BR"
	elif "DMAX" in name: name = "DMAX"
	elif "DISNEY" in name: name = "DISNEY CHANNEL"
	elif "KINOWELT" in name: name = "KINOWELT"
	elif "MDR" in name:
		if "TH" in name: name = "MDR THUERINGEN"
		elif "ANHALT" in name: name = "MDR SACHSEN ANHALT"
		elif "SACHSEN" in name: name = "MDR SACHSEN"
		else: name = 'MDR'
	elif "RBB" in name: name = "RBB"
	elif "SERVUS" in name: name = "SERVUS TV"
	elif "NITRO" in name: name = "RTL NITRO"
	elif "RTL" in name:
		if "CRIME" in name: name = "RTL CRIME"
		# elif "SUPER" in name: name = "SUPER RTL"
		elif "2" in name: name = "RTL 2"
		elif "UP" in name: name = "RTL UP"
		elif "+" in name: name = "RTL UP"
		elif "PLUS" in name: name = "RTL UP"
		elif "PASSION" in name: name = "RTL PASSION"
		elif "NITRO" in name: name = "RTL NITRO"
		elif "LIVING" in name: name = "RTL LIVING"
		else: name = "RTL"
	elif "UNIVERSAL" in name: name = "UNIVERSAL TV"
	elif "WDR" in name: name = "WDR"
	elif "PLANET" in name: name = "PLANET"
	elif "SYFY" in name: name = "SYFY"
	elif "E!" in name: name = "E! ENTERTAINMENT"
	elif "ENTERTAINMENT" in name: name = "E! ENTERTAINMENT"
	elif "STREET" in name: name = "13TH STREET"
	elif "WUNDER" in name: name = "WELT DER WUNDER"
	elif "KAB" in name and "1" in name:
		if "CLA" in name: name = "KABEL 1 CLASSICS"
		elif "DOKU" in name: name = "KABEL 1 DOKU"
		else: name = "KABEL 1"
	elif "PRO" in name:
		if "FUN" in name: name = "PRO 7 FUN"
		elif "MAXX" in name: name = "PRO 7 MAXX"
		else: name = "PRO 7"
	elif "SKY" in name:
		if not "PREMIEREN" in name and "PREMIERE" in name:
			name = name.replace("PREMIERE", "PREMIEREN")
		if "PREMIEREN" in name and not "CINEMA" in name:
			name = name.replace("SKY", "SKY CINEMA")
		if "24" in name:
			if "PREMIERE" in name: name = "SKY CINEMA PREMIEREN +24"
			else: name = "SKY CINEMA +24"
		elif "ATLANTIC" in name: name = "SKY ATLANTIC"
		elif "ACTION" in name: name = "SKY CINEMA ACTION"
		elif "BEST" in name or "HITS" in name: name = "SKY CINEMA BEST OF"
		elif "CINEMA" in name and "COMEDY" in name: name = "SKY CINEMA FUN"
		elif "COMEDY" in name: name = "SKY COMEDY"
		elif "FAMI" in name: name = "SKY CINEMA FAMILY"
		elif "SHOW" in name: name = "SKY SERIEN & SHOWS"
		elif "SPECI" in name: name = "SKY CINEMA SPECIAL"
		elif "THRILLER" in name: name = "SKY CINEMA THRILLER"
		elif "FUN" in name: name = "SKY CINEMA FUN"
		elif "CLASSIC" in name: name = "SKY CINEMA CLASSICS"
		elif "NOSTALGIE" in name: name = "SKY CINEMA CLASSICS"
		elif "KRIM" in name: name = "SKY KRIMI"
		elif "SKY 24" in name: name = "SKY CINEMA 24"
		elif "CRIME" in name: name = "SKY CRIME"
	elif "NATURE" in name: name = "SKY NATURE"
	elif "ZEE" in name: name = "ZEE ONE"
	elif "DELUX" in name: name = "DELUXE MUSIC"
	elif "DISCO" in name: name = "DISCOVERY"
	elif "TLC" in name: name = "TLC"
	elif "HISTORY" in name: name = "HISTORY"
	elif "VISION" in name: name = "MOTORVISION"
	elif "INVESTIGATION" in name or "A&E" in name: name = "A&E"
	elif "AUTO" in name: name = "AUTO MOTOR SPORT"
	elif "FOX" in name:
		if "FIX" in name: name = "FIX & FOXI"
		else: name = "SKY REPLAY"
	elif "WELT" in name:
		if "WUNDER" in name: name = "WELT DER WUNDER"
		else: name = "WELT"
	elif "NAT" in name and "GEO" in name:
		if "WILD" in name: name = "NAT GEO WILD"
		else: name = "NATIONAL GEOGRAPHIC"
	elif "3" in name and "SAT" in name: name = "3 SAT"
	elif "WARNER" in name:
		if "SERIE" in name: name = "WARNER TV SERIE"
		elif "FILM" in name: name = "WARNER TV FILM"
		elif "COMEDY" in name: name = "WARNER TV COMEDY"
	elif "VOX" in name:
		if "+" in name: name = "VOX UP"
		elif "UP" in name: name = "VOX UP"
		else: name = "VOX"
	elif "SAT" in name and "1" in name:
		if "GOLD" in name: name = "SAT 1 GOLD"
		elif "EMOT" in name: name = "SAT 1 EMOTIONS"
		else: name = "SAT 1"
	return name

def getchannels():
	if utils.addon.getSetting("hls") == "true": return get_hls_channels()
	else: return get_ts_channels()

def get_ts_channels():
	try:
		with open(groupfile, "r") as k:
			group = json.load(k)
	except: group = choose()
	chanfile = home.getProperty('chanfile')
	if chanfile:
		r = json.loads(chanfile)
		if r.get('ValidUntil', 0) > int(time.time()):
			return r.get('channels')
	channels={}
	for c in requests.get(url, params={'output': 'json'}).json():
		if "DE :" in c["name"] or c["group"] in group:
			name = filterout(c['name'])
			if name not in channels:
				channels[name] = []
			channels[name].append(c['url'])
	data={"ValidUntil": int(time.time()) + 300, "channels": channels}
	home.setProperty('chanfile', json.dumps(data))
	return channels


def get_hls_channels():
	# try:
	# 	groups = json.loads(utils.addon.getSetting("groups"))
	# except:
	# 	groups = choose()
	try:
		with open(groupfile, "r") as k:
			groups = json.load(k)
	except:
		groups = choose()
	chanfile = home.getProperty("hlschanfile")
	if chanfile:
		r = json.loads(chanfile)
		if r.get("ValidUntil", 0) > int(time.time()):
			return r.get("channels")

	channels = {}

	def _getchannels(group, cursor=0, germany=False):
		nonlocal channels
		_headers = {"user-agent": "WATCHED/1.8.3 (android)", "accept": "application/json", "content-type": "application/json; charset=utf-8", "cookie": "lng=", "watched-sig": utils.getWatchedSig()}
		_data = {"adult": True, "cursor": cursor, "filter": {"group": group}, "sort": "name"}
		r = requests.post("https://www.oha.to/oha-tv-index/directory.watched", data=json.dumps(_data), headers=_headers).json()
		nextCursor = r.get("nextCursor")
		items = r.get("items")
		for item in items:
			if germany:
				if any(ele in item["name"] for ele in ["DE :", " |D"]):
					name = filterout(item["name"])
					if name not in channels:
						channels[name] = []
					channels[name].append(item["url"])
			else:
				name = filterout(item["name"])
				if name not in channels:
					channels[name] = []
				channels[name].append(item["url"])
		if nextCursor: _getchannels(group, nextCursor, germany)

	if "Germany" in groups:
		_getchannels("Balkans", germany=True)

	for group in groups:
		_getchannels(group)

	data = {"ValidUntil": int(time.time()) + 300, "channels": channels}
	home.setProperty("hlschanfile", json.dumps(data))
	return channels


def choose():
	groups=[]
	for c in requests.get(url, params={'output': 'json'}).json():
		if c["group"] not in groups:
			groups.append(c["group"])
	new_groups = sorted(groups)
	indicies = utils.selectDialog(new_groups, "Choose Groups", True)
	group = []
	if indicies:
		for i in indicies:
			group.append(new_groups[i])
	if len(group) > 0:
		with open(groupfile, "w") as write_file:
			#json.dump(group, write_file, indent=4, sort_keys=True)
			json.dump(group, write_file)
		return group

def handle_wait(time_to_wait, kanal, heading="Abbrechen zur manuellen Auswahl", text1="Starte Stream in  : ", text2="STARTE  : "):
	progress = xbmcgui.DialogProgress()
	progress.create(heading, text2+kanal)
	secs=0
	# percent=0 ## wird nicht benötigt
	increment = int(100 / time_to_wait)
	cancelled = False
	while secs < time_to_wait:
		secs += 1
		percent = increment*secs
		secs_left = str((time_to_wait - secs))
		if utils.PY2:progress.update(percent,text2+kanal,text1+str(secs_left))
		else:progress.update(percent,text2+kanal+"\n"+text1+str(secs_left))
		xbmc.sleep(1000)
		if (progress.iscanceled()):
			cancelled = True
			break
	if cancelled == True:
		progress.close()
		return False
	else:
		progress.close()
		return True

def livePlay(name):
	m = getchannels()[name]
	i = 0
	title = None
	# bei manuelle Auswahll - immer anzeigen, unabhänig von der Anzahl der verfügbaren Streams
	if int(utils.addon.getSetting('auto')) == 2:
		cap=[]
		i = 0
		while i < len(m):
			i+=1
			cap.append('STREAM'+' '+str(i))
		i = utils.selectDialog(cap, '', False)
		if i < 0: return
		title = '%s (%s/%s)' % (name, i + 1, len(m))  # wird verwendet für infoLabels

	elif not int(utils.addon.getSetting('auto')) == 2 and len(m) > 1:
		if int(utils.addon.getSetting('auto')) == 0:
			# Autoplay - rotieren bei der Stream Auswahl
			# ist wichtig wenn z.B. der erste gelistete Stream nicht funzt
			if utils.addon.getSetting('idn') == name:
				i = int(utils.addon.getSetting('num'))
				i += 1
				if i == len(m): i = 0
			utils.addon.setSetting('idn', name)
			utils.addon.setSetting('num', str(i))
			title = '%s (%s/%s)' % (name, i + 1, len(m))  # wird verwendet für infoLabels
		elif int(utils.addon.getSetting('auto')) == 1:
			isTrue = handle_wait(int(utils.addon.getSetting('count')), name)
			if isTrue:
				# Streamauswahl - Zufall
				i = random.randint(0, len(m) - 1)
			else:	# Dialog aufrufen
				cap = []
				i = 0
				while i < len(m):
					i += 1
					cap.append('STREAM' + ' ' + str(i))
				i = utils.selectDialog(cap, '', False)
				if i < 0: return
			title = '%s (%s/%s)' %(name, i+1, len(m))  # wird verwendet für infoLabels

	n = m[i]
	#url = n + '?n=1&b=5&vavoo_auth=' + utils.getAuthSignature() + '|User-Agent=VAVOO/2.6'
	url = resolve_link(n) if utils.addon.getSetting("hls") == "true" else "%s?n=1&b=5&vavoo_auth=%s|User-Agent=VAVOO/2.6" % (n, utils.getAuthSignature())
	o = xbmcgui.ListItem(name)
	#o.setPath(n + '?n=1&b=5&vavoo_auth=' + utils.getAuthSignature() + '|User-Agent=VAVOO/2.6')
	if xbmc.getCondVisibility('System.HasAddon("inputstream.ffmpegdirect")'):
		o.setMimeType("video/mp2t")
		o.setProperty("inputstream", "inputstream.ffmpegdirect")
		o.setProperty("inputstream.ffmpegdirect.is_realtime_stream", "true")
		o.setProperty("inputstream.ffmpegdirect.stream_mode", "timeshift")
	o.setProperty('IsPlayable', 'true')
	title = title if title else name
	o.setInfo(type='Video', infoLabels={'Title': title, 'Plot': '[B]%s[/B] - Stream %s von %s' % (name, i+1, len(m))}) # so kann man die Stream Auswahl auch sehen (Info)
	#xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, o)
	# xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)
	xbmc.Player().play(url, o)
	xbmc.executebuiltin('Action(ParentDir)')
			
def channels():
	try:
		with open(favoritenfile, "r") as f:
			lines= json.load(f)
	except: lines=[]
	results = getchannels()
	for name in results:
		name = name.strip()
		index = len(results[name])
		title = name if index == 1 else '%s  (%s)' % (name, index)
		url = utils.getPluginUrl({'name': name})
		o = xbmcgui.ListItem(name)
		o.setArt({'poster': 'DefaultTVShows.png', 'icon': 'DefaultTVShows.png'}) # kein icon - dummy.png
		cm = []
		if not name in lines:
			cm.append(('zu TV Favoriten hinzufügen', 'RunPlugin(%s?action=addTvFavorit&channel=%s)' % (sys.argv[0], name.replace('&', '%26').replace('+', '%2b'))))
			plot = ''
		else:
			plot = '[COLOR gold]TV Favorit[/COLOR]' #% name
			cm.append(('von TV Favoriten entfernen', 'RunPlugin(%s?action=delTvFavorit&channel=%s)' % (sys.argv[0], name.replace('&', '%26').replace('+', '%2b'))))
		cm.append(('Einstellungen', 'RunPlugin(%s?action=addonSettings)' % sys.argv[0]))
		o.addContextMenuItems(cm)
		o.setInfo(type='Video', infoLabels={'Title': title, 'Plot': plot})
		#o.setProperty('IsPlayable', 'true')
		#o.setProperty('selectaction', 'play')
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, o, isFolder=True)
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)
	xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=True)

def favchannels():
	try:
		with open(favoritenfile, "r") as f:
			lines= json.load(f)
	except: return
	for name in getchannels():
		if not name in lines: continue
		url = utils.getPluginUrl({'name': name})
		o = xbmcgui.ListItem(name)
		# DefaultRecentlyAddedMovies
		#o.setArt({'icon': 'DefaultAddonTvInfo.png'})
		o.setArt({'poster': 'DefaultRecentlyAddedMovies.png', 'icon': 'DefaultTVShows.png'})  # kein icon
		cm = []
		cm.append(('von TV Favoriten entfernen', 'RunPlugin(%s?action=delTvFavorit&channel=%s)' % (sys.argv[0], name.replace('&', '%26').replace('+', '%2b'))))
		cm.append(('Einstellungen', 'RunPlugin(%s?action=settings)' % sys.argv[0]))
		o.addContextMenuItems(cm)
		o.setInfo(type='Video', infoLabels={'Title': name, 'Plot': '[COLOR gold]Liste der eigene Live Favoriten[/COLOR]'})
		#o.setProperty('IsPlayable', 'true')
		#o.setProperty('selectaction', 'play')
		xbmcplugin.addDirectoryItem(int(sys.argv[1]), url, o, isFolder=True)
	xbmcplugin.addSortMethod(int(sys.argv[1]), xbmcplugin.SORT_METHOD_VIDEO_TITLE)
	xbmcplugin.endOfDirectory(int(sys.argv[1]), succeeded=True, cacheToDisc=False)

def addtvfavorit(name):
	try:
		with open(favoritenfile, "r") as k:
			lines = json.load(k)
	except: lines= []
	finally:
		lines.append(name)
		with open(favoritenfile, "w") as k:
			json.dump(lines, k)
		xbmc.executebuiltin('Container.Refresh')

def deltvfavorit(name):
	try:
		with open(favoritenfile, "r") as k:
			lines = json.load(k)
	except: lines=[]
	finally:
		if name in lines:
			lines.remove(name)
		with open(favoritenfile, "w") as k:
			json.dump(lines, k)
		if len(lines) == 0:
			xbmc.executebuiltin('Action(ParentDir)')
		else:
			xbmc.executebuiltin('Container.Refresh')