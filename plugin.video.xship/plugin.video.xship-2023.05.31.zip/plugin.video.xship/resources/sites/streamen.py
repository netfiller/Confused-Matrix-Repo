# -*- coding: utf-8 -*-

#2023-05-10

import json, sys
from resources.lib.ParameterHandler import ParameterHandler
from resources.lib.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.control import progressDialog, quote_plus, unescape, quote, execute
from resources.lib.indexers.navigatorXS import navigator
from resources.lib.utils import isBlockedHoster

oNavigator = navigator()
addDirectoryItem = oNavigator.addDirectoryItem
setEndOfDirectory = oNavigator._endDirectory
xsDirectory = oNavigator.xsDirectory
params = ParameterHandler()

SITE_IDENTIFIER = 'streamen'
SITE_NAME = 'Streamen'
SITE_ICON = 'streamen.png'
URL_MAIN = 'https://wwv.streamen.cx'
URL_MOVIES = URL_MAIN + '/filme.html'
URL_SERIES = URL_MAIN + '/serien.html'
URL_SEARCH = URL_MAIN + '/recherche?q=%s'

def load():
    logger.info('Load %s' % SITE_NAME)
    addDirectoryItem("Filme", 'runPlugin&site=%s&function=showEntries&sUrl=%s' % (SITE_NAME, URL_MOVIES), SITE_ICON, 'DefaultMovies.png')
    addDirectoryItem("Serien", 'runPlugin&site=%s&function=showEntries&sUrl=%s' % (SITE_NAME, URL_SERIES), SITE_ICON, 'DefaultTVShows.png')
    addDirectoryItem("Genre", 'runPlugin&site=%s&function=showGenre&sUrl=%s' % (SITE_NAME, URL_MAIN), SITE_ICON, 'DefaultGenre.png')
    addDirectoryItem("Suche", 'runPlugin&site=%s&function=showSearch' % SITE_NAME, SITE_ICON, 'DefaultAddonsSearch.png')
    setEndOfDirectory()

def showEntries(entryUrl=False, sSearchText=None, bGlobal=False):
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl)
    oRequest.cacheTime = 60 * 60 * 6  # HTML Cache Zeit 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = '<div[^>]*class="short-images[^"]*"[^>]*>.*?'  # start element
    pattern += '<a[^>]*href="([^"]*)"[^>]*>.*?'  # url
    pattern += '<img[^>]*src="([^"]*)".*?'  # thumbnail
    pattern += 'alt="([^"]*).*?'  # name
    pattern += '<\/div>'  # end element
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch: return
    items = []
    for sUrl, sThumbnail, sName in aResult:
        if sSearchText and not cParser.search(sSearchText, sName): continue
        item = {}
        isTvshow = True if 'serien' in sUrl else False  # Wenn Serie dann True
        if isTvshow:
            infoTitle = sName
            if bGlobal: sName = SITE_NAME + ' - ' + sName + ' (Serie)'
            else: sName = sName + ' (Serie)'
        else:
            infoTitle = sName
            if bGlobal: sName = SITE_NAME + ' - ' + sName
        item.setdefault('infoTitle', infoTitle)  # für "Erweiterte Info"
        item.setdefault('title', sName)
        item.setdefault('entryUrl', sUrl)
        item.setdefault('isTvshow', isTvshow)
        item.setdefault('poster', sThumbnail)
        item.setdefault('plot', '[B][COLOR blue]{0}[/B][CR]{1}[/COLOR][CR]'.format(SITE_NAME, infoTitle))
        items.append(item)
    xsDirectory(items, SITE_NAME)

    if bGlobal: return

    if sSearchText == None:
        isMatchNextPage, sNextUrl = cParser().parseSingleResult(sHtmlContent, 'pages-next">.*?href="([^"]+)')
        if isMatchNextPage:
            sNextUrl = URL_MAIN + sNextUrl
            params.setParam('sUrl', sNextUrl)
            addDirectoryItem('[B]>>>[/B]', 'runPlugin&' + params.getParameterAsUri(), 'next.png', 'DefaultVideo.png')
    # oGui.setView('tvshows' if isTvshow else 'movies')
    setEndOfDirectory()

def showGenre(entryUrl=False):
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl)
    oRequest.cacheTime = 60 * 60 * 48  # 48 Stunden
    sHtmlContent = oRequest.request()
    pattern = '<ul id="sub-menu".*?</ul>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    isMatch, aResult = cParser.parse(sHtmlContainer, 'href="([^"]+).*?>([^<]+)')
    if not isMatch: return
    for sUrl, sName in aResult:
        if sUrl.startswith('/'): sUrl = URL_MAIN + sUrl
        params.setParam('sUrl', sUrl)
        addDirectoryItem(sName, 'runPlugin&site=%s&function=showEntries&sUrl=%s' % (SITE_NAME, sUrl), SITE_ICON, 'DefaultGenre.png')
    setEndOfDirectory()

def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    oRequest = cRequestHandler(sUrl)
    oRequest.cacheTime = 60 * 60 * 24 # HTML Cache Zeit 1 Tag
    sHtmlContent = oRequest.request()
    isMatch, aResult = cParser.parse(sHtmlContent, '<div[^>]*class="short-images[^"]*"[^>]*>.*?<a[^>]*href="([^"]*)"[^>]*>.*?<img[^>]*src="([^"]*)".*?<figcaption>Staffel\s([\d]+)') # Sucht den Staffel Eintrag und d fügt die Anzahl hinzu
    if not isMatch: return
    meta = json.loads(params.getValue('meta'))
    infoTitle = meta["infoTitle"]
    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, 'fsynopsis">.*?<p>([^<]+)') # Staffel Beschreibung
    items = []
    for sUrl, sThumbnail, sSeason in aResult:
        item = {}
        item.setdefault('title', 'Staffel ' + sSeason)
        item.setdefault('entryUrl', sUrl)
        item.setdefault('poster', sThumbnail)
        item.setdefault('season', sSeason)
        item.setdefault('infoTitle', infoTitle)
        item.setdefault('sFunction', 'showEpisodes')
        item.setdefault('isTvshow', True)
        if isDesc: # optional
            try: sDesc = unescape(sDesc)
            except: pass
            sDesc = sDesc.replace("\r", "").replace("\n", "")
            item.setdefault('plot', '[B][COLOR blue]{0}[/B][CR]{1}[/COLOR][CR]{2}'.format(SITE_NAME, infoTitle, quote(sDesc)))
        else:
            item.setdefault('plot', '[B][COLOR blue]{0}[/B][CR]{1}[/COLOR][CR]'.format(SITE_NAME, infoTitle))
        items.append(item)
    xsDirectory(items, SITE_NAME)
    #     cGui().setView('seasons')
    setEndOfDirectory()

def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    meta = json.loads(params.getValue('meta'))
    oRequest = cRequestHandler(sUrl)
    oRequest.cacheTime = 60 * 60 * 24
    sHtmlContent = oRequest.request()
    isMatch, aResult = cParser.parse(sHtmlContent, '_LI2">.*?href="([^"]+).*?Folge\s([\d]+)</span>')
    if not isMatch: return
    items = []
    infoTitle = meta["infoTitle"]
    for sUrl, sEpisode in aResult:
        item = {}
        if sUrl.startswith('//'): sUrl = 'https:' + sUrl
        item.setdefault('title', 'Folge ' + sEpisode)
        item.setdefault('entryUrl', sUrl)
        item.setdefault('poster', meta["poster"])
        item.setdefault('season', int(meta["season"]))
        item.setdefault('episode', int(sEpisode))
        item.setdefault('infoTitle', infoTitle)
        item.setdefault('plot', '[B][COLOR blue]{0}[/B][CR]{1}[/COLOR][CR]Staffel {2} - Episode {3}'.format(SITE_NAME, infoTitle, meta["season"], sEpisode))
        items.append(item)
    xsDirectory(items, SITE_NAME)
    # cGui().setView('episodes')
    setEndOfDirectory()

def getHosters():
    isProgressDialog=True  # TODO - Wert aus settings - bei globaler Suche keinen ProgressDialog beim Plugin!
    isResolve = True  # TODO - Wert aus settings
    items = []
    sUrl = ParameterHandler().getValue('entryUrl')
    sHtmlContent = cRequestHandler(sUrl).request()
    pattern = '<div data-url="([^"]+).*?player_v_DIV_5">([^<]*)\s' # sUrl, sName
    isMatch, aResult = cParser().parse(sHtmlContent, pattern)
    if isMatch:
        meta = json.loads(params.getValue('meta'))
        sThumbnail = meta['poster']
        if meta.get('isTvshow', False):
            meta.setdefault('mediatype', 'tvshow')
            infoTitle = meta['infoTitle'] + ' S%sE%s' % (str(meta['season']), str(meta['episode']))
        else:
            meta.setdefault('mediatype', 'movie')
            pattern = 'fsynopsis"><p>([^<]+)'
            isMatch, sDesc = cParser().parseSingleResult(sHtmlContent, pattern)
            infoTitle = meta['infoTitle']
            if isMatch:  # optional
                meta.pop('plot')
                try: sDesc = unescape(sDesc)
                except: pass
                sDesc = sDesc.replace("\r", "").replace("\n", "")
                meta.setdefault('plot', '[B][COLOR blue]{0}[/B][CR]{1}[/COLOR][CR]{2}'.format(SITE_NAME, infoTitle, quote(sDesc)))

        if isProgressDialog: progressDialog.create('xStream V2', 'Erstelle Hosterliste ...')
        t = 0
        if isProgressDialog: progressDialog.update(t)

        for sUrl, sHoster in aResult:
            t += 100 / len(aResult)
            if isProgressDialog: progressDialog.update(int(t), '[CR]Überprüfe Stream von ' + sHoster)
            if 'ayer' in sHoster: continue
            elif isBlockedHoster(sHoster)[0]: continue  # Hoster aus settings.xml oder deaktivierten Resolver ausschließen
            elif sUrl.startswith('/'): sUrl = URL_MAIN + sUrl # URL_MAIN + übergebener Link
            Request = cRequestHandler(sUrl, caching=False)
            Request.request()
            sUrl = Request.getRealUrl()  # hole reale URL von der Umleitung
            if isResolve:
                isBlocked, sUrl = isBlockedHoster(sUrl, resolve=isResolve)
                if isBlocked: continue
            elif isBlockedHoster(sUrl)[0]: continue
            items.append((sHoster, infoTitle, meta, isResolve, sUrl, sThumbnail))
        if isProgressDialog:  progressDialog.close()
    url = '%s?action=showHosters&items=%s' % (sys.argv[0], quote(json.dumps(items)))
    execute('Container.Update(%s)' % url)

def showSearch():
    sSearchText = oNavigator.showKeyBoard()
    if not sSearchText: return
    showEntries(URL_SEARCH % sSearchText, sSearchText, bGlobal=False)

def _search(sSearchText):
    showEntries(URL_SEARCH % sSearchText, sSearchText, bGlobal=True)

