# -*- coding: utf-8 -*-

# 2022-10-09
# edit 2023-05-21

import time , os #, pkgutil
import xbmcvfs
from resources.lib.requestHandler import cRequestHandler
from resources.lib.control import getSetting, setSetting, urlparse, addonPath, translatePath, sleep
from resources.lib.pluginHandler import cPluginHandler
from resources.lib.utils import download_url, unzip

# Download Media Files
dest = translatePath(os.path.join(addonPath, 'resources'))
contr = translatePath(os.path.join(addonPath, 'resources', 'media', 'sites', 'megakino.png'))
if not os.path.exists(contr):
    url = 'https://watchone.github.io/zips/media.zip'
    src = translatePath(os.path.join('special://temp', url.split('/')[-1]))
    download_url(url, src)
    src = translatePath(os.path.join('special://temp', url.split('/')[-1]))
    dirs ='media'
    unzip(src, dest, folder=None)
    xbmcvfs.delete(src)

# xstream plugin DB erstellen
oPluginHandler = cPluginHandler()
oPluginHandler.getAvailablePlugins()

# Html Cache beim KodiStart löschen
deltaDay = int(getSetting('cacheDeltaDay', 2))
deltaTime = 60*60*24*deltaDay # Tage
currentTime = int(time.time())
# einmalig
if getSetting('delHtmlCache') == 'true':
    cRequestHandler('').clearCache()
    setSetting('lastdelhtml', str(currentTime))
    setSetting('delHtmlCache', 'false')
    exit()
# alle x Tage
if currentTime >= int(getSetting('lastdelhtml', 0)) + deltaTime:
    cRequestHandler('').clearCache()
    setSetting('lastdelhtml', str(currentTime))
#print (int(getSetting('lastdelhtml', 0)))

# add domain name - nicht alle, nur die, wo Änderungen zu erwarten sind
# Scraper(Seiten) ein- / ausschalten
#  [(providername, domainname), ...]     providername identisch mit dateiname
domains = [('cinemathek', 'cinemathek.net'), ('filmpalast', 'filmpalast.to'), ('kinofox', 'kinofox.su'), ('kinokiste', 'kinokiste.cloud')]   #, ('kinomax', 'kinomax.rocks')]
domains += [('kkiste', 'kkiste.direct'), ('megakino', 'megakino.co'), ('movie2k', 'www2.movie2k.ch'), ('movie4k', 'movie4k.pics')]
domains += [('moviedream', 'moviedream.co'), ('movieking', 'movieking.cc'), ('streamen', 'streamen.cx'), ('xcine', 'xcine.click'), ('kino', 'www.kino.ws')]

for item in domains:
    _provider, _domain = item
    domain = getSetting('provider.'+ _provider +'.domain', _domain)
    base_link = 'https://' + domain
    try:
        oRequest = cRequestHandler(base_link, caching=False)
        oRequest.request()
        status_code = int(oRequest.getStatus())
        #print(str(status_code) + '  ' + _provider)
        if 300 <= status_code <= 400:
            url = oRequest.getRealUrl()
            #setSetting('provider.'+ _provider +'.base_link', url)
            setSetting('provider.' + _provider + '.domain', urlparse(url).hostname)
            setSetting('provider.' + _provider + '.check', 'true')
        elif status_code == 200:
            #setSetting('provider.' + provider + '.base_link', base_link)
            setSetting('provider.' + _provider + '.domain', urlparse(base_link).hostname)
            setSetting('provider.' + _provider + '.check', 'true')
        else:
            setSetting('provider.' + _provider + '.check', 'false')
            setSetting('provider.' + _provider + '.domain', domain)
    except:
        setSetting('provider.' + _provider + '.check', 'false')
        setSetting('provider.' + _provider + '.domain', domain)
        pass

setSetting('provider.movieking.check', 'false')
#setSetting('provider.movie4k', 'false')
#setSetting('provider.kinomax.check', 'false')

# print()
##  limited
# setSetting('provider.cinemathek', 'false')
# setSetting('provider.movie2k', 'false')
# setSetting('provider.moviedream', 'false')
# setSetting('provider.streamen', 'false')
# setSetting('provider.vavoo', 'false')


# providerDict = []
# sourceFolderLocation = os.path.join(os.path.dirname(__file__), "scrapers", "scrapers_source")
# sourceSubFolders = [x[1] for x in os.walk(sourceFolderLocation)][0]
# for i in sourceSubFolders:
#     try:
#         for loader, module_name, is_pkg in pkgutil.walk_packages([os.path.join(sourceFolderLocation, i)]):
#             if is_pkg:
#                 continue
#             try:
#                 mn = str(module_name).split('_')[0]
#             except:
#                 mn = str(module_name)
#             providerDict.append(mn)
#     except:
#         pass
# print()

# Html Cache beim Start löschen
# try:
#     import os
#     from sys import version_info
#     import xbmcvfs, xbmcaddon
#
#     if version_info[0] == 2:
#         from xbmc import translatePath
#         profilePath = translatePath(xbmcaddon.Addon().getAddonInfo('profile')).decode('utf-8')
#     else:
#         from xbmcvfs import translatePath
#         profilePath = translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
#     cachePath = os.path.join(profilePath, 'htmlcache')
#     if os.path.isdir(cachePath):
#         files = os.listdir(cachePath)
#         for file in files:
#             file = os.path.join(cachePath, file)
#             if os.path.getsize(file) <= 400000:
#                 os.remove(file)
# except:
#     pass
