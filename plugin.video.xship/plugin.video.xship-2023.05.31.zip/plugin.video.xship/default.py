# -*- coding: UTF-8 -*-

# 2023-05-10

import sys, xbmcgui, json
from os.path import join
from resources.lib import control
from resources.lib.pluginHandler import cPluginHandler
from resources.lib.utils import isBlockedHoster
from resources.lib.indexers import navigatorXS

addonPath = control.addonPath
sys.path.append(join(addonPath, 'resources','sites'))
oPluginHandler = cPluginHandler()

# import pydevd
# pydevd.settrace('localhost', port=12345, stdoutToServer=True, stderrToServer=True)

params = dict(control.parse_qsl(control.urlsplit(sys.argv[2]).query))

action = params.get('action')
name = params.get('name')
table = params.get('table')
title = params.get('title')
source = params.get('source')

# --- live TV - play favoriten -----
if name and action == None:
    from resources.lib import vjlive
    vjlive.livePlay(params['name'])

# ------ navigator --------------
elif action == None or action == 'root':
    from resources.lib.indexers import navigator
    navigator.navigator().root()

# -------- vavoo TV -------
elif action == 'vavoo_tv':
    from resources.lib.indexers import navigator
    navigator.navigator().vavooTv()
elif action == 'channels_tv':
    from resources.lib import vjlive
    vjlive.channels()
elif action == 'livetv':
    from resources.lib import vjlive
    vjlive.livePlay(params['name'])
elif action == 'favchannels':
    from resources.lib import vjlive
    vjlive.favchannels()
elif action == 'addTvFavorit':
    from resources.lib import vjlive
    vjlive.addtvfavorit(params['channel'])
elif action == 'delTvFavorit':
    from resources.lib import vjlive
    vjlive.deltvfavorit(params['channel'])

# -------- xstream -------
elif action == 'xstream':
    navigatorXS.navigator().root()

elif action == 'globalSearch':
    sSearchText = params.get('sSearchText')
    if not sSearchText:
        k = control.keyboard('', "Globale Suche")
        k.doModal()
        term = k.getText() if k.isConfirmed() else None
        if term is None or term == '': exit()
        sSearchText = term.strip()
    from resources.lib.searchDB import save_query
    save_query(sSearchText)
    navigatorXS.navigator().searchGlobal(sSearchText=sSearchText)

elif action == 'globalHistory':
    navigatorXS.navigator().globalHistory()

elif action == 'runPlugin':
    site = params.get('site') if params.get('site') else name
    pluginID, plugin = oPluginHandler.getPluginFromDB(site)
    module = __import__(pluginID)
    function = params.get('function') if params.get('function') else 'load'
    func = getattr(module , function)
    func()

elif action == 'showHosters':
    items = params.get('items')
    navigatorXS.navigator().showHosters(items)
    
elif action == 'playXS':
    url = params.get('url')
    isResolve = params.get('resolved')
    if not eval(isResolve):
        if not control.visible(): control.busy()
        import resolveurl as resolver
        try:
            hmf = resolver.HostedMediaFile(url=url, include_disabled=False, include_universal=False)
            if hmf.valid_url():
                url = hmf.resolve()
                control.idle()
        except:
            control.idle()
            xbmcgui.Dialog().notification('xStream V2', 'Kein Stream vorhanden!', control.addonIcon(), 5000, False)
            exit()
    meta = json.loads(params.get('meta'))
    # from resources.lib import player
    # player.player().run(title, url, meta)
    #xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    control.resolveUrl(int(sys.argv[1]), True, control.item(label=params.get('title'), path=url))

elif action == 'viewInfo':
    from resources.lib.tmdbinfo import WindowsBoxes
    sCleanTitle = params.get('infoTitle')
    sMediaType = params.get('sMediaType')
    sYear = params.get('sYear')
    WindowsBoxes(sCleanTitle, sCleanTitle, sMediaType, sYear)

elif action == 'downloadXS':
    name = params.get('name')
    image = params.get('image')
    sUrl = params.get('url')
    isResolve = params.get('isResolve')
    if not isResolve:
        isBlocked, sUrl = isBlockedHoster(sUrl, resolve=True)
        if isBlocked: exit()
    from resources.lib import downloader
    try: downloader.download(name, image, sUrl)
    except: pass

elif action == 'toolNavigatorXS':

    navigatorXS.navigator().toolsXS()

#  --------- end ------

elif action == 'playExtern':
    import json
    if not control.visible(): control.busy()
    try:
        sysmeta = {}
        for key, value in params.items():
            if key == 'action': continue
            elif key == 'year' or key == 'season' or key == 'episode': value = int(value)
            if value == 0: continue
            sysmeta.update({key : value})
        if int(params.get('season')) == 0:
            mediatype = 'movie'
        else:
            mediatype = 'tvshow'
        sysmeta.update({'mediatype': mediatype})
        # if control.getSetting('hosts.mode') == '2':
        #     sysmeta.update({'select': '2'})
        # else:
        #     sysmeta.update({'select': '1'})
        sysmeta.update({'select': control.getSetting('hosts.mode')})
        sysmeta = json.dumps(sysmeta)
        params.update({'sysmeta': sysmeta})
        from resources.lib import sources
        sources.sources().play(params)
    except:
        pass

elif action == 'movieNavigator':
    from resources.lib.indexers import navigator
    navigator.navigator().movies()

elif action == 'tvNavigator':
    from resources.lib.indexers import navigator
    navigator.navigator().tvshows()

elif action == 'toolNavigator':
    from resources.lib.indexers import navigator
    navigator.navigator().tools()

elif action == "settings":
    from resources import settings
    settings.run(params)

elif action == 'UpdatePlayCount':
    from resources.lib import playcountDB
    playcountDB.UpdatePlaycount(params)
    control.execute('Container.Refresh')

# elif action == 'searchNavigator':
#     from resources.lib.indexers import navigator
#     navigator.navigator().search()


# listings -------------------------------

elif action == 'listings':
    from resources.lib.indexers import listings
    listings.listings().get(params)

elif action == 'movieYears':
    from resources.lib.indexers import listings
    listings.listings().movieYears()

elif action == 'movieGenres':
    from resources.lib.indexers import listings
    listings.listings().movieGenres()

elif action == 'tvGenres':
    from resources.lib.indexers import listings
    listings.listings().tvGenres()

# search ----------------------
elif action == 'searchNew':
    from resources.lib import searchDB
    searchDB.search_new(table)

elif action == 'searchClear':
    from resources.lib import searchDB
    searchDB.remove_all_query(table)
    # if len(searchDB.getSearchTerms()) == 0:
    #     control.execute('Action(ParentDir)')

elif action == 'searchDelTerm':
    from resources.lib import searchDB
    searchDB.remove_query(name, table)
    # if len(searchDB.getSearchTerms()) == 0:
    #     control.execute('Action(ParentDir)')

# person ----------------------
elif action == 'person':
    from resources.lib.indexers import person
    person.person().get(params)

elif action == 'personSearch':
    from resources.lib.indexers import person
    person.person().search()

elif action == 'personCredits':
    from resources.lib.indexers import person
    person.person().getCredits(params)

# elif action == 'personChangeSearchDB':
#     from resources.lib.indexers import person
#     person.person().changeSearchDB()

elif action == 'playfromPerson':
    if not control.visible(): control.busy()
    sysmeta = json.loads(params['sysmeta'])
    if sysmeta['mediatype'] == 'movie':
        from resources.lib.indexers import movies
        sysmeta = movies.movies().super_meta('', id=sysmeta['tmdb_id'])
        sysmeta = json.dumps(sysmeta)
    else:
        from resources.lib.indexers import tvshows
        sysmeta = tvshows.tvshows().super_meta('', id=sysmeta['tmdb_id'])
        sysmeta = control.quote_plus(json.dumps(sysmeta))

    params.update({'sysmeta': sysmeta})
    from resources.lib import sources
    sources.sources().play(params)

# movies ----------------------
elif action == 'movies':
    from resources.lib.indexers import movies
    movies.movies().get(params)

elif action == 'moviesSearch':
    from resources.lib.indexers import movies
    movies.movies().search()

# elif action == 'movieChangeSearchDB':
#     from resources.lib.indexers import movies
#     movies.movies().changeSearchDB()

# tvshows ---------------------------------
elif action == 'tvshows': # 'tvshowPage'
    from resources.lib.indexers import tvshows
    tvshows.tvshows().get(params)

elif action == 'tvshowsSearch':
    from resources.lib.indexers import tvshows
    tvshows.tvshows().search()

# seasons ---------------------------------
elif action == 'seasons':
    from resources.lib.indexers import seasons
    seasons.seasons().get(params)  # params

# episodes ---------------------------------
elif action == 'episodes':
    from resources.lib.indexers import episodes
    episodes.episodes().get(params)

# sources ---------------------------------
elif action == 'play':
    if not control.visible(): control.busy()
    from resources.lib import sources
    sources.sources().play(params)

elif action == 'addItem':
    from resources.lib import sources
    sources.sources().addItem(title)

elif action == 'playItem':
    #log_utils.log(__name__ + ' - start playItem', log_utils.LOGINFO)
    # if control.getSetting('watcher.control') == 'true':
    #     #log_utils.log(__name__ + ' - watcher playItem', log_utils.LOGINFO)
    #     control.setSetting(id='watcher.control', value='false')
    # else:
    if not control.visible(): control.busy()
    from resources.lib import sources
    sources.sources().playItem(title, source)

# Settings ------------------------------
elif action == 'addonSettings':
    control.openSettings()

elif action == 'resetSettings':
    status = control.resetSettings()
    if status:
        control.reload_profile()
        control.sleep(500)
        control.execute('RunAddon("%s")' % control.addonId)
        
elif action == 'resolverSettings':
    import resolveurl as resolver
    resolver.display_settings()
    from resources.lib.indexers import navigator
    navigator.navigator().tools()

elif action == 'downloadNavigator':
    from resources.lib.indexers import navigator
    navigator.navigator().downloads()

elif action == 'download':
    image = params.get('image')
    from resources.lib import downloader
    from resources.lib import sources
    try: downloader.download(name, image, sources.sources().sourcesResolve(json.loads(source)[0], True))
    except: pass
