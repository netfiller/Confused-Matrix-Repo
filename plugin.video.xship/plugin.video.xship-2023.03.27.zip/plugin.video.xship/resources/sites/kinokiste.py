# -*- coding: utf-8 -*-

#2023-03-20

from resources.lib.ParameterHandler import ParameterHandler
from resources.lib.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.control import progressDialog, quote_plus, keyboard, infoDialog, getSetting, listDir
from resources.lib.indexers.navigatorXS import navigator
from resources.lib.utils import isBlockedHoster

oNavigator = navigator()
addDirectoryItem = oNavigator.addDirectoryItem
setEndOfDirectory = oNavigator._endDirectory
xsDirectory = oNavigator.xsDirectory
params = ParameterHandler()

SITE_IDENTIFIER = 'kinokiste'
SITE_NAME = 'Kinokiste'
SITE_ICON = 'kinokiste.png'
DOMAIN = getSetting('plugin_'+ SITE_IDENTIFIER +'.domain', 'kinokiste.cloud')
URL_MAIN = 'https://' + DOMAIN + '/'
URL_NEW = URL_MAIN + 'kinofilme-online/'
URL_KINO = URL_MAIN + 'aktuelle-kinofilme-im-kino/'
URL_ANIMATION = URL_MAIN + 'animation/'
URL_SERIES = URL_MAIN + 'serienstream-deutsch/'
URL_SEARCH = URL_MAIN + '?do=search&subaction=search&titleonly=3&full_search=0&story=%s'

def load(): # Menu structure of the site plugin
    logger.info('Load %s' % SITE_NAME)
    addDirectoryItem("Neu", 'runPlugin&site=%s&function=showEntries&new=True&sUrl=%s' % (SITE_NAME, URL_NEW), SITE_ICON, 'DefaultMovies.png')  # New
    addDirectoryItem("Aktuelle Filme im Kino", 'runPlugin&site=%s&function=showEntries&sUrl=%s' % (SITE_NAME, URL_KINO), SITE_ICON, 'DefaultMovies.png')  # Current films in the cinema
    addDirectoryItem("Animationsfilme", 'runPlugin&site=%s&function=showEntries&sUrl=%s' % (SITE_NAME, URL_ANIMATION), SITE_ICON, 'DefaultVideo.png')  # Animated Films
    addDirectoryItem("Serien", 'runPlugin&site=%s&function=showEntries&sUrl=%s' % (SITE_NAME, URL_SERIES), SITE_ICON, 'DefaultTVShows.png')  # Series
    addDirectoryItem("Genre", 'runPlugin&site=%s&function=showGenre&sUrl=%s' % (SITE_NAME, URL_MAIN), SITE_ICON, 'DefaultGenre.png')    # Genre
    addDirectoryItem("Suche", 'runPlugin&site=%s&function=showSearch' % SITE_NAME, SITE_ICON, 'DefaultVideo.png')   # Search
    setEndOfDirectory()

def showGenre():
    params = ParameterHandler()
    entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl)
    oRequest.cacheTime = 60 * 60 * 48  # 48 Stunden
    sHtmlContent = oRequest.request()
    pattern = '<nav\s+class="header-nav">(.*?)</nav>'
    isMatch, sHtmlContainer = cParser.parseSingleResult(sHtmlContent, pattern)
    aResult = []
    if isMatch:
        pattern = '<li>\s*<a\s+href="([^"]+)">([^<]+)</a></li>'
        isMatch, aResult = cParser.parse(sHtmlContainer, pattern)
    if not isMatch: return
    for sUrl, sName in aResult:
        if cParser.search('DMCA', sName): continue
        addDirectoryItem(sName, 'runPlugin&site=%s&function=showEntries&sUrl=%s' % (SITE_NAME, sUrl), SITE_ICON, 'DefaultVideo.png')
    setEndOfDirectory()

def showEntries(entryUrl=False, sSearchText=None, bGlobal=False):
    params = ParameterHandler()
    if not entryUrl: entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl)
    oRequest.cacheTime = 60 * 60 * 6  # 6 Stunden
    sHtmlContent = oRequest.request()
    pattern = '<span\s+class="new_movie\d+">\s*<a\s+href="([^"]+)">[^<]*</a>\s*</span>.*?<img\s+alt="([^"]+)"\s+src="([^"]+)">\s*</span>\s*<span\s+class="fl-quality[^"]+">([^<]+)</span>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch: return
    items = []
    for sUrl, sName, sThumbnail, sQuality in aResult:
        if sSearchText:
            pattern = '\\b%s\\b' % sSearchText.lower()
            if not cParser().search(pattern , sName.lower()): continue
        item = {}
        if sThumbnail.startswith('/'):
            sThumbnail = URL_MAIN + sThumbnail
        isTvshow, aName = cParser.parseSingleResult(sName, '(.*?)\s+-\s+Staffel\s+(\d+)')
        if isTvshow:
            infoTitle, sSE = aName
            item.setdefault('infoTitle', quote_plus(infoTitle))  # für "Erweiterte Info"
            item.setdefault('season', sSE)
            item.setdefault('sFunction', 'showEpisodes')  # wenn abweichend! - nicht showSeasons !
        else:
            item.setdefault('infoTitle', quote_plus(sName))
        if bGlobal: sName = SITE_NAME + ' - ' + sName
        sName = quote_plus(sName)   # wichtig!
        item.setdefault('title', sName)
        item.setdefault('entryUrl', sUrl)
        item.setdefault('isTvshow', isTvshow)
        item.setdefault('poster', sThumbnail)
        # optional
        item.setdefault('quality', sQuality)
        items.append(item)
    xsDirectory(items, SITE_NAME)

    if bGlobal: return

    if sSearchText == None:
        pattern = '<span\s+class="swchItem">\s*<a\s+href="([^"]+)">&raquo;</a>\s*</span>'
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, pattern)
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            addDirectoryItem('[B]>>>[/B]', 'runPlugin&' + params.getParameterAsUri(), 'next.png', 'DefaultVideo.png')

    setEndOfDirectory()

def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('entryUrl')
    meta = eval(params.getValue('meta'))
    oRequest = cRequestHandler(sUrl)
    oRequest.cacheTime = 60 * 60 * 24
    sHtmlContent = oRequest.request()
    pattern = '<li\s+id="serie-([^"]+)">\s*<a\s+href="#">([^<]+)</a>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch: return
    sThumbnail = meta["poster"]
    infoTitle = meta["infoTitle"]
    infoTitle = quote_plus(infoTitle) # notwendig ??
    items = []
    for episodeId, episodeName in aResult:
        item = {}
        item.setdefault('title', episodeName)
        item.setdefault('entryUrl', sUrl)
        item.setdefault('poster', sThumbnail)
        item.setdefault('episodeId', episodeId)
        item.setdefault('season', episodeId.rsplit('_')[0])
        item.setdefault('episode', episodeId.rsplit('_')[1])
        item.setdefault('infoTitle', infoTitle)
        item.setdefault('plot', '[B][COLOR blue]{0}[/COLOR][/B]'.format(infoTitle))
        item.setdefault('sFunction', 'showHosters')
        items.append(item)
    xsDirectory(items, SITE_NAME)    # sFunction='showHosters'
    setEndOfDirectory()

def showHosters():
    isProgressDialog = True  # TODO - Wert aus settings - bei globaler Suche keinen ProgressDialog beim Plugin!
    isResolve = True  # TODO - Wert aus settings
    # progressDialog = control.progressDialog if control.getSetting('progress.dialog') == '0' else control.progressDialogBG
    sUrl = ParameterHandler().getValue('entryUrl')
    if sUrl.startswith('//'): sUrl = 'https:' + sUrl
    oRequest = cRequestHandler(sUrl)
    # oRequest.cacheTime = 60 * 60 * 1
    sHtmlContent = oRequest.request()
    meta = eval(params.getValue('meta'))
    if meta.get('isTvshow', False):
        episodeId = meta['episodeId']
        pattern = '<li>\s*<a\s+href="#"\s+id="[^"]+-%s"\s+data-link="([^"]+)">\s*([^<]+)</a>\s*</li>' % episodeId
    else:
        pattern = '<li>\s*<a\s+href="#"\s+data-link="([^"]+)">\s*<i>\s*</i>\s*([^<]+)</a>\s*</li>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if isMatch:
        sThumbnail = meta['poster']
        sTitle = meta['infoTitle']
        if meta.get('isTvshow', False): meta.setdefault('mediatype', 'tvshow')
        else: meta.setdefault('mediatype', 'movie')
        if isProgressDialog: progressDialog.create('xStream V2', 'Erstelle Hosterliste ...')
        t = 0
        if isProgressDialog: progressDialog.update(t)
        items = []
        for sUrl, sHoster in aResult:
            if sUrl.startswith('//'): sUrl = 'https:' + sUrl
            if isProgressDialog: progressDialog.update(int(t), '[CR]Überprüfe Stream von ' + sHoster.upper())
            if isResolve:
                isBlocked, sUrl = isBlockedHoster(sUrl, resolve=isResolve)
                if isBlocked: continue
            elif isBlockedHoster(sUrl)[0]: continue
            items.append((sHoster, sTitle, meta, isResolve, sUrl, sThumbnail))
            t += 100 / len(aResult)

        if isProgressDialog:  progressDialog.close()
        oNavigator.showHoster(items)

def showSearch():
    sSearchText = oNavigator.showKeyBoard()
    if not sSearchText: return
    showEntries(URL_SEARCH % quote_plus(sSearchText), sSearchText, bGlobal=False)

def _search(sSearchText):
    showEntries(URL_SEARCH % quote_plus(sSearchText), sSearchText, bGlobal=True)

