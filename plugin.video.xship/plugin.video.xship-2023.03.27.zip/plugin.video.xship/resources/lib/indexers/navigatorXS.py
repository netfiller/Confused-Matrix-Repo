# -*- coding: UTF-8 -*-

# 2023-03-12

import sys
from os.path import join
import xbmcvfs
from resources.lib import control
from resources.lib.pluginHandler import cPluginHandler
from resources.lib.tools import cParser
from six import iteritems


sysaddon = sys.argv[0]
syshandle = int(sys.argv[1]) if len(sys.argv) > 1 else ''
artPath = control.artPath()
addonFanart = control.addonFanart()
oPluginHandler = cPluginHandler()


class navigator:
    def root(self):
        self.addDirectoryItem('Globale Suche', 'globalSearch','search.png', 'DefaultAddonsSearch.png')
        from resources.lib.searchDB import getSearchTerms
        if len(getSearchTerms()) >= 1:
            self.addDirectoryItem('[B]Globale Suche ([COLOR red]Verlauf[/COLOR])[/B]', 'globalHistory', 'search.png', 'DefaultAddonsSearch.png')
        aPlugins = oPluginHandler.getAvailablePluginsFromDB()
        aPlugins = sorted(aPlugins, key=lambda i: i['name'])
        for aPlugin in aPlugins:
            self.addDirectoryItem(aPlugin['name'], 'runPlugin&name=%s' % aPlugin['name'], (aPlugin['name'] + '.png').lower(), 'DefaultVideo.png')  # &function=load
        downloads = True if len(control.listDir(control.getSetting('download.movie.path'))[0]) > 0 or len(
            control.listDir(control.getSetting('download.tv.path'))[0]) > 0 else False
        if downloads:
            self.addDirectoryItem("Downloads", 'downloadNavigator', 'manuel_update.png', 'DefaultFolder.png')
        self.addDirectoryItem("Werkzeuge", 'toolNavigatorXS', 'settings.png', 'DefaultAddonProgram.png')

        self._endDirectory(cache=False)

# TODO
    def addDirectoryItem(self, name, query, thumb, icon, context=None, queue=False, isAction=True, isFolder=True):
        url = '%s?action=%s' % (sysaddon, query) if isAction == True else query
        thumb = self.getMedia(thumb, icon)
        # laut kodi doku - ListItem([label, label2, path, offscreen])
        listitem = control.item(name, offscreen=True)  # Removed iconImage and thumbnailImage
        listitem.setArt({'poster': thumb})
        if not context == None:
            cm = []
            cm.append((context[0], 'RunPlugin(%s?action=%s)' % (sysaddon, context[1])))
            listitem.addContextMenuItems(cm)

        isMatch, sPlot = cParser.parseSingleResult(query, "plot'.*?'([^']+)")
        if not isMatch: sPlot = '[COLOR blue]{0}[/COLOR]'.format(name)
        if isFolder:
            listitem.setInfo('video', {'overlay': 4, 'plot': control.unquote_plus(sPlot)})
            listitem.setIsFolder(True)
        self.addFanart(listitem, query)
        control.addItem(syshandle, url, listitem, isFolder)

    def _endDirectory(self, content='', cache=True, sorted=False):  # addons  videos  files
        # https://romanvm.github.io/Kodistubs/_autosummary/xbmcplugin.html#xbmcplugin.setContent
        control.content(syshandle, content)
        if sorted: control.sortLabel(syshandle)
        control.directory(syshandle, succeeded=True, cacheToDisc=cache)

    def addFanart(self, listitem, query):
        if control.getSetting('fanart') == 'true':
            isMatch, sFanart = cParser.parseSingleResult(query, "fanart'.*?'([^']+)")
            if isMatch:
                sFanart = self.getMedia(sFanart)
                listitem.setProperty('fanart_image', sFanart)
            else:
                listitem.setProperty('fanart_image', addonFanart)
#TODO
    def getMedia(self, mediaFile=None, icon=None):
        if xbmcvfs.exists(join(artPath, mediaFile)):
            mediaFile = join(artPath, mediaFile)
        elif xbmcvfs.exists(join(artPath, 'sites', mediaFile)):
            mediaFile = join(artPath, 'sites', mediaFile)
        elif mediaFile.startswith('http'):
            return mediaFile
        else:
            mediaFile = icon
        return mediaFile

    def toolsXS(self):
        self.addDirectoryItem("[B]"+control.addonName.upper()+"[/B]: EINSTELLUNGEN", 'addonSettings', 'xstream_settings.png', 'DefaultAddonProgram.png', isFolder=False)
        # self.addDirectoryItem("[B]"+control.addonName.upper()+"[/B]: Reset Settings (außer Konten)", 'resetSettings', 'nightly_update.png', 'DefaultAddonProgram.png', isFolder=False)
        self.addDirectoryItem("[B]Resolver[/B]: EINSTELLUNGEN", 'resolverSettings', 'resolveurl_settings.png', 'DefaultAddonProgram.png', isFolder=False)
        self._endDirectory()    # addons  videos  files

    def xsDirectory(self, items, SITE_NAME):
        if items == None or len(items) == 0:
            control.idle()
            sys.exit()
        for i in items:
            context = None
            sName = control.unquote_plus(i['title'])
            label = '%s  (%s)' % (sName, i['year']) if i.get('year', False) and not i.get('isTvshow', False) else sName
            meta = dict((k, v) for k, v in iteritems(i))
            meta.setdefault('fanart', 'fanartV2.jpg')
            try:
                if i['isTvshow']:  # Season
                    meta.update({'isTvshow': True})
                    meta.update({'mediatype': 'tvshow'})
                    DefaultThumb = 'DefaultTVShows.png'
                    sFunc = i['sFunction'] if i.get('sFunction', False) else 'showSeasons'
                    #if not SITE_NAME in sName:
                    context = ('Erweiterte Info', 'viewInfo&infoTitle=%s&sYear=%s&sMediaType=%s' % (i['infoTitle'], i.get('year', False), 'tvshow'))
                else:  # Movie
                    meta.update({'isTvshow': False})
                    meta.update({'mediatype': 'movie'})
                    DefaultThumb = 'DefaultMovies.png'
                    sFunc = i['sFunction'] if i.get('sFunction', False) else 'showHosters'
                    #if not SITE_NAME in sName:
                    context = ('Erweiterte Info', 'viewInfo&infoTitle=%s&sYear=%s&sMediaType=%s' % (i['infoTitle'], i.get('year', False), 'movie'))
            except:  # Episode
                meta.update({'isTvshow': True})
                meta.update({'mediatype': 'episode'})
                DefaultThumb = 'DefaultTVShowTitle'
                sFunc = i['sFunction'] if i.get('sFunction', False) else 'showHosters'
                context = ('Erweiterte Info', 'viewInfo&infoTitle=%s&sYear=%s&sMediaType=%s' % (i['infoTitle'], i.get('year', False), 'movie'))
            self.addDirectoryItem(label, 'runPlugin&site=%s&function=%s&meta=%s&entryUrl=%s' % (SITE_NAME, sFunc, meta, i['entryUrl']), i['poster'], DefaultThumb, context=context)

    def globalHistory(self):
        self.addDirectoryItem('Neue Suche', 'globalSearch', 'search.png', 'DefaultAddonsSearch.png', isFolder=True)
        from resources.lib.searchDB import getSearchTerms
        match = getSearchTerms()
        lst = []
        delete_option = False
        # for i in match:
        for index, i in enumerate(match):
            term = control.py2_encode(i['query'])
            if term not in lst:
                delete_option = True
                self.addDirectoryItem(term, 'globalSearch&sSearchText=%s' % term, 'search.png',
                                                       'DefaultAddonsSearch.png',
                                                       context=("Suchanfrage löschen", 'searchDelTerm&name=%s' % index))
                lst += [(term)]
        if delete_option:
            self.addDirectoryItem("[B]Suchverlauf löschen[/B]", 'searchClear', 'plugin_info.png', 'DefaultAddonProgram.png', isFolder=False)
        self._endDirectory(cache=False)  # addons  videos  files

    def showKeyBoard(self, sDefaultText=""):
        # Create the keyboard object and display it modal
        oKeyboard = control.keyboard(sDefaultText, "Suche")
        oKeyboard.doModal()
        sTerm = oKeyboard.getText() if oKeyboard.isConfirmed() else None
        if sTerm is None or sTerm == '': return
        sSearchText = sTerm.strip()
        if len(sSearchText) > 0: return sSearchText
        return

    def showHoster(self, items):
        if len(items) > 0:
            for item in items:
                context = self.getContextMenu('Download', item)
                sHoster, sTitle, meta, isResolve, sUrl, sThumbnail = item
                self.addDirectoryItem(sHoster, 'playXS&title=%s&meta=%s&resolved=%s&url=%s' % (sTitle, meta, isResolve, sUrl), sThumbnail, 'DefaultVideo.png',
                             isFolder=False, context=context)
            self._endDirectory()
        else:
            return control.infoDialog("Nichts gefunden", icon = 'INFO',time=2000)


    def getContextMenu(self, context, item):
        def cDownload(item):
            downloads = True if control.getSetting('downloads') == 'true' and (
                    control.exists(control.translatePath(control.getSetting('download.movie.path'))) or
                    control.exists(control.translatePath(control.getSetting('download.movie.path')))
                    ) else False
            if downloads:
                sHoster, sTitle, meta, isResolve, sUrl, sThumbnail = item
                return ('Download', 'downloadXS&name=%s&image=%s&url=%s&isResolve=%s' % (sTitle, sThumbnail, sUrl, isResolve))
            else: return None

        if context == 'Download': return cDownload(item)
        # elif:
