# -*- coding: UTF-8 -*-
# xcine
# 2022-12-20
# edit 2023-02-02

import re
import resolveurl as resolver
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, source_utils, dom_parser
from scrapers.modules.tools import cParser
from resources.lib.control import urljoin, getSetting

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['xcine.click']
        self.domains = [getSetting('provider.xcine.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        self.search_link = self.base_link + '/index.php?do=search'
        self.checkHoster = False if getSetting('provider.kkiste.checkHoster') == 'false' else True
        # self.checkHoster = False # test only
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        t = [cleantitle.get(i) for i in set(titles) if i]
        years = (year, year + 1, year - 1, 0)
        links = []
        for sSearchText in titles:
            try:
                oRequest = cRequestHandler(self.search_link)
                oRequest.addParameters('do', 'search')
                oRequest.addParameters('subaction', 'search')
                oRequest.addParameters('search_start', '0')
                oRequest.addParameters('full_search', '1')
                oRequest.addParameters('result_from', '1')
                oRequest.addParameters('story', sSearchText)
                oRequest.addParameters('titleonly', '3')
                sHtmlContent = oRequest.request()
                #r = dom_parser.parse_dom(sHtmlContent, 'div', attrs={'id': 'dle-content'})[0].content
                pattern = 'movie-item__link.*?href="([^"]+).*?alt="([^"]+).*?movie-item__label">([^<]+).*?nowrap.*?span>(\d+).*?<span>([^<]+)'
                isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                if not isMatch:
                    continue

                for sUrl, sName, sQuality, sYear, sGenre in aResult:
                    if 'Demnächst' in sGenre:  continue

                    if season == 0:
                        if cleantitle.get(sName) in t and int(sYear) in years:
                            links.append({'url': sUrl, 'name': sName, 'quality': sQuality, 'year': sYear})
                    else:
                        if cleantitle.get(sName.split('-')[0].strip()) in t and str(season) in sName.split('-')[1]:
                            links.append({'url': sUrl, 'name': sName.split('-')[0].strip(), 'quality': sQuality, 'year': sYear})

                if len(links) == 0:
                    for sUrl, sName, sQuality, sYear, sGenre in aResult:
                        if 'Demnächst' in sGenre:  continue
                        if '1080' in sQuality: sQuality = '1080p'
                        if season == 0 and int(sYear) == year:
                            for a in t:
                                if any([a in cleantitle.get(sName)]):
                                    links.append({'url': sUrl, 'name': sName, 'quality': sQuality, 'year': sYear})
                                    break

                if len(links) > 0: break
            except:
                continue

        if len(links) == 0: return self.sources

        try:
            url = links[0]['url']
            self.sInfo = links[0]['quality']
            self.sQuality = self.setQuality(links[0]['quality'])
            if not url: return
            query = urljoin(self.base_link, url)
            oRequest = cRequestHandler(query, caching=False)
            oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
            sHtmlContent = oRequest.request()
            if season == 0:
                pattern = 'span data-link="([^"]+)' #.*?\s([^<]+)'
                isMatch, aResult = cParser().parse(sHtmlContent, pattern)
            else:
                r = dom_parser.parse_dom(sHtmlContent, 'div', attrs={'class': 'series'})[0].content
                pattern = 'Episoden %s.*?</ul' % str(episode)
                isMatch, aResult = cParser().parseSingleResult(r, pattern)
                pattern = 'link="([^"]+)'
                isMatch, aResult = cParser().parse(aResult, pattern)

            if self.checkHoster:
                from resources.lib import workers
                threads = []
                for sUrl in aResult:
                    # print(sUrl)
                    threads.append(workers.Thread(self.chk_link, sUrl, hostDict, season, episode))
                [i.start() for i in threads]
                [i.join() for i in threads]
            else:
                for sUrl in aResult:
                    #if sName == 'Trailer': continue
                    if sUrl.startswith('/'): sUrl = re.sub('//', 'https://', sUrl)
                    if sUrl.startswith('/'): sUrl = 'https:/' + sUrl
                    valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
                    if not valid or 'youtube' in hoster: continue
                    if 'dood' in hoster: continue   #ka temp off
                    self.sources.append({'source': hoster, 'quality': self.sQuality, 'language': 'de', 'info': self.sInfo,
                                    'url': sUrl, 'direct': False})
            return self.sources
        except:
            return self.sources

    def chk_link(self, sUrl, hostDict, season, episode):
        try:
            #if 'mixdrop' in sUrl:
            #    print(sUrl)
            if 'youtube' in sUrl or 'vod' in sUrl: return
            if sUrl.startswith('/'): sUrl = re.sub('//', 'https://', sUrl)
            if sUrl.startswith('/'): sUrl = 'https:/' + sUrl
            valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
            if not valid: return
            hmf = resolver.HostedMediaFile(url=sUrl, include_disabled=True, include_universal=False)
            if hmf.valid_url():
                url = hmf.resolve()
                if url: self.sources.append({'source': hoster, 'quality': self.sQuality, 'language': 'de', 'info': self.sInfo, 'url': url, 'direct': True})
        except:
            return

    def setQuality(self, quality):
        if 'HD' in quality: sQuality = '1080p'
        elif 'WEBRip' in quality: sQuality = '720p'
        else: sQuality = 'SD'
        return sQuality


    def resolve(self, url):
        try:
            return url
        except:
            return
