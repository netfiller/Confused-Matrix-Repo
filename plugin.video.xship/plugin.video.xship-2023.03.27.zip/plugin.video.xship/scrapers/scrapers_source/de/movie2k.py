# -*- coding: UTF-8 -*-
# megakino to (clone)  # https://movie2k.at/
# 2022-11-04
# edit 2023-03-13

import re, json
import resolveurl as resolver
from resources.lib.control import getSetting
from resources.lib import workers
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import source_utils

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['movie2k.at']
        self.domains = [getSetting('provider.movie2k.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        self.api = 'api.' + self.domains[0]
        self.search_link = 'https://'+ self.api +'/data/browse?lang=2&keyword=%s&year=%s&rating=&votes=&genre=&country=&cast=&directors=&type=%s&order_by=&page=1' # 'browse?c=movie&m=filter&year=%s&keyword=%s'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        lUrl = []
        jSearch = self.search(titles, year, season, imdb)
        if jSearch == []: return
        if season > 0:
            for k in jSearch:
                try:
                    if k['s'] == season:
                        streams = k['streams']
                        for i in range(len(streams) - 1, 0, -1):
                            if streams[i]['e'] == episode:
                                sUrl = streams[i]['stream']
                                valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
                                if not valid: continue
                                lUrl.append(sUrl)
                except:
                    continue
        else:
            for k in jSearch:
                try:
                    streams = k['streams']
                    for i in range(len(streams) - 1, 0, -1):
                        sUrl = streams[i]['stream']
                        valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
                        if not valid: continue
                        lUrl.append(sUrl)
                except:
                    continue

        if lUrl == []: return self.sources
        threads = []
        for sUrl in lUrl:
            threads.append(workers.Thread(self.chk_link, sUrl, hostDict, season, episode))
        [i.start() for i in threads]
        [i.join() for i in threads]

        if len(self.sources) <= 5:
            return self.sources
        else:
            sources = []
            for i in range(0, 6): sources.append(self.sources[i])
            return sources

    def resolve(self, url):
        return  url

    def search(self, titles, year, season, imdb):
        jSearch = []
        mtype = 'movies'
        if season > 0:
            year = ''
            mtype = 'tvseries'
        for title in titles:
            try:
                query = self.search_link % (title, year, mtype)
                oRequest = cRequestHandler(query)
                oRequest.addHeaderEntry('Referer', self.base_link + '/')
                oRequest.addHeaderEntry('Host', self.api)
                oRequest.addHeaderEntry('Origin', self.base_link)
                oRequest.addHeaderEntry('Connection', 'keep-alive')
                Search = oRequest.request()
                Search = re.sub(r'\\\s+\\', '\\\\',   Search) # error - Rick and Morty
                jSearch = json.loads(Search)['movies']
                if jSearch == []:  continue
                if jSearch[0].get('imdb_id', False) and  not jSearch[0].get('imdb_id') == imdb: continue
                return jSearch
            except:
                continue
        return jSearch

    def chk_link(self, sUrl, hostDict, season, episode):
        try:
            # if 'mixdrop' in sUrl:
            #    print(sUrl)
            if 'youtube' in sUrl or 'vod' in sUrl: return
            if sUrl.startswith('/'): sUrl = re.sub('//', 'https://', sUrl)
            if sUrl.startswith('/'): sUrl = 'https:/' + sUrl
            valid, hoster = source_utils.is_host_valid(sUrl, hostDict)
            if not valid: return
            hmf = resolver.HostedMediaFile(url=sUrl, include_disabled=True, include_universal=False)
            if hmf.valid_url():
                url = hmf.resolve()
                if url: self.sources.append({'source': hoster, 'quality': 'HD', 'language': 'de', 'url': url, 'direct': True})
        except:
            return

