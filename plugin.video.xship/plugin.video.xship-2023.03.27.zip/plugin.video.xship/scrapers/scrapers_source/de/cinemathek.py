# -*- coding: UTF-8 -*-
# cinemathek
# 2022-07-19
# edit 2023-01-31

import json
from scrapers.modules.tools import cParser
from resources.lib.requestHandler import cRequestHandler
from scrapers.modules import cleantitle, dom_parser
from resources.lib.control import getSetting

class source:
    def __init__(self):
        self.priority = 1
        self.language = ['de']
        self.domains = ['cinemathek.net']
        self.domains = [getSetting('provider.cinemathek.domain', self.domains[0])]
        self.base_link = 'https://' + self.domains[0]
        self.search_link = self.base_link + '/wp-json/dooplay/search/?keyword=%s&nonce=3800137d61'
        self.sources = []

    def run(self, titles, year, season=0, episode=0, imdb='', hostDict=None):
        try:
            t = [cleantitle.get(i) for i in set(titles) if i]
            #years = (year, year+1, year-1, 0)
            links = []
            for title in titles:
                try:
                    oRequest = cRequestHandler(self.search_link %title)
                    jSearch = json.loads(oRequest.request()).values()
                    if 'Keine Ergebnisse' in jSearch: continue
                    for i in jSearch:
                        if i == 'no_verify_nonce': break
                        elif season == 0 and str(year) != i['extra']['date']:continue
                        if cleantitle.get(i['title']) in t:
                            links.append({'url': i['url'], 'name': i['title']})
                    if len(links) > 0: break
                except:
                    return self.sources

            if len(links) == 0: return self.sources
            for link in links:
                sHtmlContent = cRequestHandler(link['url']).request()
                if season != 0:
                    isMatch = False
                    r = dom_parser.parse_dom(sHtmlContent, 'div', attrs={'class': 'episodiotitle'})
                    for i in r:
                        if not '-%sx%s' % (season, episode) in i.content: continue
                        pattern = "https://cinemathek.net/episodes/.*?%sx%s/" % (season, episode)
                        isMatch, url = cParser.parseSingleResult(i.content, pattern)
                        sHtmlContent = cRequestHandler(url).request()
                        if isMatch: break
                    if not isMatch: continue
                pattern = "player-option-\d.*?type.*?'([^']+).*?(\d+).*?(\d)"
                isMatch, aResult = cParser.parse(sHtmlContent, pattern)
                if not isMatch: return self.sources
                for i in aResult:
                    sUrl = 'https://cinemathek.net/wp-json/dooplayer/v2/%s/%s/%s' %(i[1], i[0], i[2])
                    self.sources.append({'source': 'Cinemathek '+ i[2], 'quality': '720p', 'language': 'de', 'url': sUrl, 'direct': False})
            return self.sources
        except:
            return self.sources

    def resolve(self, url):
        try:
            url = json.loads(cRequestHandler(url).request()).get("embed_url")
            return url
        except:
            return