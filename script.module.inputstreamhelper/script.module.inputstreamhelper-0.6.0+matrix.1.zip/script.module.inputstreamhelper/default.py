# -*- coding: utf-8 -*-
''' This is the actual InputStream Helper API script entry point '''

from __future__ import absolute_import, division, unicode_literals
import sys
from lib.inputstreamhelper.api import run

run(sys.argv)
