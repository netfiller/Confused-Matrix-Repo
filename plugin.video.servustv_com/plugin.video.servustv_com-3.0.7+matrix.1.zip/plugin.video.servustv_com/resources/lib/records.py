﻿# -*- coding: utf-8 -*-

from .common import *


def get_ListItem(info, category, phrase, extras, aback, addType=1, folder=True, STOCK=False):
	cineType, tagline, description, Note_1, Note_2, Note_3, genre = ("" for _ in range(7))
	seriesname, DIGS, startTIMES, endTIMES, season, episode, duration, uvz = (None for _ in range(8))
	entries = []
	### Codeübersetzungen = e2fda2e1-58ff-4474-a49a-a2df01309998 = Neues aus Österreich / 9878c650-06dc-403e-9389-3ad738eca2ae = Talks & Meinungen / e440011b-c6f6-447f-97e3-3f7d2853689d = Ab in die Natur ###
	acronym = ['discover-featured', 'episode-topic', 'latest-videos', 'e2fda2e1-58ff-4474-a49a-a2df01309998', '9878c650-06dc-403e-9389-3ad738eca2ae', 'e440011b-c6f6-447f-97e3-3f7d2853689d']
	unwanted = ['mehr zu', 'top-themen', 'live', 'tagesaktuelle', 'wissen & natur', ' entdecken', 'beliebt', ' & mehr', ' ...']
	title_short = info.get('title') if info.get('title', '') else info.get('label')
	eid = info.get('id', '')
	if info.get('content_type', ''):
		cineType = info.get('content_type').replace('show', 'tvshow').replace('clip', 'tvshow').replace('film', 'movie')
	elif aback.get('content_type', ''):
		cineType = aback.get('content_type').replace('show', 'tvshow').replace('clip', 'tvshow').replace('film', 'movie')
	if info.get('subheading', ''):
		if cineType in ['episode', 'tvshow']: seriesname = info.get('subheading')
		elif cineType == 'movie': tagline = info.get('subheading')
	cineType = cineType if cineType in ['episode', 'movie', 'tvshow', 'video'] else 'movie'
	if seriesname: Note_1 = translation(32101).format(str(seriesname))
	if 'long_description' in info or 'long_description' in aback:
		if info.get('long_description', '') and len(info['long_description']) > 10:
			DIGS = info['long_description']
		if DIGS is None and aback.get('long_description', '') and len(aback['long_description']) > 10:
			DIGS = aback['long_description']
	if DIGS is None and 'short_description' in info or 'short_description' in aback:
		if info.get('short_description', '') and len(info['short_description']) > 10:
			DIGS = info['short_description']
		if DIGS is None and aback.get('short_description', '') and len(aback['short_description']) > 10:
			DIGS = aback['short_description']
	if DIGS: description = DIGS
	matchSE = re.findall('([0-9]+)', info['season'], re.S) if info.get('season', '') else None # Staffel 1
	if matchSE: season = matchSE[0].zfill(2)
	matchEP = re.findall('([0-9]+)', info['chapter'], re.S) if info.get('chapter', '') else None # Episode 6 - Infrastruktur
	if matchEP: episode = matchEP[0].zfill(2)
	if cineType == 'episode' and season and episode: Note_2 = translation(32102).format(str(season), str(episode))
	elif cineType == 'episode' and season is None and episode: Note_2 = translation(32103).format(str(episode))
	stepUP = info.get('status', {}) if info.get('status', '') else info # Datumseinträge gibt es sowohl unter diesem Level als auch unter einem Level eine Stufe höher
	if str(stepUP.get('start_time'))[:4] not in ['None', '0', '1970']: # 2021-03-28T10:00:00.000+02:00
		LOCALstart = get_Local_DT(stepUP['start_time'][:19])
		startTIMES = LOCALstart.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if str(stepUP.get('end_time'))[:4] not in ['None', '0', '1970']: # 2021-03-28T10:30:00.000+02:00
		LOCALend = get_Local_DT(stepUP['end_time'][:19])
		endTIMES = LOCALend.strftime('%d{0}%m{0}%y {1} %H{2}%M').format('.', '•', ':')
	if startTIMES and endTIMES: Note_3 = translation(32104).format(str(startTIMES), str(endTIMES))
	elif startTIMES and endTIMES is None: Note_3 = translation(32105).format(str(startTIMES))
	elif seriesname and startTIMES is None and endTIMES is None: Note_3 = '[CR]' #  in ['show', 'system']
	if info.get('content_color', '') and len(info['content_color']) > 0:
		genre = info.get('content_color')[0]
	if info.get('playable', '') is True or info.get('action', '') == 'play':
		uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'playVideo', 'url': eid}))
		folder = False
		duration = int(info['duration']) // 1000 if str(info.get('duration')).isdigit() else None
	elif category == 'COLLECTION':
		uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'listGeneralFull', 'url': eid, 'phrase': 'collections'}))
	elif category == 'PRODUCT':
		uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'listGeneralFull', 'url': eid, 'phrase': 'products'}))
	elif category == 'PLAYLIST':
		uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'listGeneralFull', 'url': eid, 'phrase': 'playlists'}))
	elif category == 'THEME':
		uvz = '{0}?{1}'.format(HOST_AND_PATH, urlencode({'mode': 'listThemes', 'url': eid, 'phrase': 'products'}))
	name = title_short if (not any(x in aback.get('id', '') for x in acronym) and aback.get('item_type', '') in ['mixed', 'video']) or seriesname is None else title_short+' - '+seriesname
	FULL_PLOT = Note_1+Note_2+Note_3+description if Note_1+Note_2+Note_3+description != "" else '...'
	if not folder:
		for method in getSorting(): xbmcplugin.addSortMethod(ADDON_HANDLE, method)
	else:
		xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
		xbmcplugin.addSortMethod(ADDON_HANDLE, xbmcplugin.SORT_METHOD_LABEL)
	LEM = xbmcgui.ListItem(name)
	if KODI_ov20:
		videoInfoTag = LEM.getVideoInfoTag()
		if season not in ['0', 'None', None]: videoInfoTag.setSeason(int(season))
		if episode not in ['0', 'None', None]: videoInfoTag.setEpisode(int(episode))
		videoInfoTag.setTvShowTitle(seriesname)
		videoInfoTag.setTitle(name)
		videoInfoTag.setTagLine(tagline)
		videoInfoTag.setPlot(FULL_PLOT)
		if duration: videoInfoTag.setDuration(int(duration))
		videoInfoTag.setGenres([genre])
		videoInfoTag.setStudios(['ServusTV'])
		if not folder: videoInfoTag.setMediaType(cineType)
	else:
		ilabels = {}
		if season not in ['0', 'None', None]: ilabels['Season'] = season
		if episode not in ['0', 'None', None]: ilabels['Episode'] = episode
		ilabels['Tvshowtitle'] = seriesname
		ilabels['Title'] = name
		ilabels['Tagline'] = tagline
		ilabels['Plot'] = FULL_PLOT
		if duration: ilabels['Duration'] = duration
		ilabels['Genre'] = genre
		ilabels['Studio'] = 'ServusTV'
		if not folder: ilabels['Mediatype'] = cineType # mediatype  = "video", "movie", "tvshow", "season", "episode" , "musicvideo"
		LEM.setInfo(type='Video', infoLabels=ilabels)
	PHOTO, WALL = icon, defaultFanart
	LEM.setArt({'icon': PHOTO, 'thumb': PHOTO, 'fanart': WALL})
	if 'resources' in info or 'resources' in aback and aback.get('id', '') not in ['discover', 'calendar']:
		if info.get('resources', ''):
			num, resources, STOCK = info.get('id', ''), info.get('resources', []), True
		if not STOCK and aback.get('resources', ''):
			num, resources, STOCK = aback.get('id', ''), aback.get('resources', []), True
		if STOCK:
			LEM.setArt({'fanart': get_Picture(num, resources, 'landscape')})
			LEM.setArt({'landscape': get_Picture(num, resources, 'landscape')})
			LEM.setArt({'banner': get_Picture(num, resources, 'banner')})
			LEM.setArt({'poster': get_Picture(num, resources, 'portrait')})
			LEM.setArt({'thumb': get_Picture(num, resources, 'square')})
			PHOTO = str(get_Picture(num, resources, 'square'))
			WALL = str(get_Picture(num, resources, 'landscape'))
	if ('all_episodes' in eid or eid.count('-') > 2) and aback.get('content_type', '') in ['event', 'show', 'system', 'subchannel'] and not any(w in str(title_short).lower() for w in unwanted):
		if xbmcvfs.exists(channelFavsFile):
			with open(channelFavsFile, 'r') as fp:
				watch = json.load(fp)
				for item in watch.get('items', []):
					if item.get('url') == eid: addType = 2
		if addType == 1:
			FAVOR_TITLE = title_short if not any(n in str(title_short).lower() for n in ['verfügbar', 'ganze ']) else aback.get('title', 'DEFAULT')
			FAVOR_PLOT = aback.get('title', '...')+'[CR][CR]'+description.replace('\n', '[CR]') if DIGS else '...'
			entries.append([translation(30651), 'RunPlugin({0}?{1})'.format(HOST_AND_PATH, urlencode({'mode': 'favs', 'action': 'ADD', 'name': FAVOR_TITLE,
				'pict': PHOTO, 'url': eid, 'plot': FAVOR_PLOT, 'wallpaper': WALL, 'cineType': cineType}))])
	if not folder:
		LEM.setProperty('IsPlayable', 'true')
		LEM.setContentLookup(False)
		entries.append([translation(30654), 'Action(Queue)'])
	LEM.addContextMenuItems(entries)
	if extras:
		debug_MS(extras+" ### TITLE = {} || CINETYPE = {} ###".format(name, cineType))
		debug_MS(extras+" ### EID = {} || is FOLDER = {} || DURATION = {} ###".format(eid, str(folder), str(duration)))
		if STOCK: debug_MS(extras+" ### THUMB = {} ###".format(PHOTO))
	return (uvz, LEM, folder)
