# script.module.iapc
Inter-Addon Procedure Call addon for Kodi

Download the latest version from [here](https://github.com/lekma/script.module.iapc/releases/).
