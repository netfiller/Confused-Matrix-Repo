This is an automatically generated repository for the KODI distribution of
xbmcswift2. Only use this repository if you know what you are doing.

This version is only python3 compatible (matrix and above)
